#!/usr/bin/env node
// Trial an unmerged Codex Gerrit change in ProtoWiki by committing a tiny,
// deterministic diff instead of vendored tarballs.
//
//   npm run codex:patch -- <gerrit-url-or-change>   build + emit the patch
//   npm run codex:reset                             delete the patch, back to stock
//
// Output lands in patches/codex/, replacing any previous patch. All heavy work
// (cloning + building Codex) happens locally; postinstall re-applies the diff
// with no Codex build step. See .agents/skills/protowiki-codex-patching/.

import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'

import {
  CODEX_PACKAGES,
  PATCH_DIR,
  formatContent,
  hasPatch,
  installedPackageDir,
  isFormattable,
  loadJsDiff,
  loadPrettier,
  patchFileName,
  prettierVersion,
  readManifest,
  readPatchMarker,
  readPrettierOptions,
  run,
  sha256,
  tryRun,
} from './lib-codex-patch.mjs'
import { clearViteCache, ensureCodex } from './lib-codex-state.mjs'

const CACHE_ROOT = path.join(os.tmpdir(), 'protowiki-codex-gerrit-cache')
const CODEX_REPO_DIR = path.join(CACHE_ROOT, 'design-codex')
const GERRIT_REPO = 'https://gerrit.wikimedia.org/r/design/codex'

const PACKAGE_DIRS = new Map([
  ['@wikimedia/codex', 'packages/codex'],
  ['@wikimedia/codex-design-tokens', 'packages/codex-design-tokens'],
  ['@wikimedia/codex-icons', 'packages/codex-icons'],
])

// Build order matters: codex imports codex-icons' built output, so tokens and
// icons must be built before codex.
const CODEX_BUILD_ORDER = [
  '@wikimedia/codex-design-tokens',
  '@wikimedia/codex-icons',
  '@wikimedia/codex',
]

function parseChangeNumber(input) {
  if (!input) {
    throw new Error('Missing Gerrit URL or change number.')
  }
  const trimmed = input.trim()
  if (/^\d+$/.test(trimmed)) {
    return trimmed
  }
  const url = new URL(trimmed)
  const match =
    url.pathname.match(/\/\+\/(\d+)(?:\/)?$/) ||
    url.pathname.match(/\/c\/[^/]+\/[^/]+\/\+\/(\d+)(?:\/)?$/)
  if (match) {
    return match[1]
  }
  throw new Error(`Could not parse Gerrit change number from: ${input}`)
}

function stripXssiPrefix(body) {
  const lines = body.split('\n')
  return lines[0] === `)]}'` ? lines.slice(1).join('\n') : body
}

async function fetchJson(url) {
  const response = await fetch(url)
  if (!response.ok) {
    throw new Error(`Request failed (${response.status}): ${url}`)
  }
  return JSON.parse(stripXssiPrefix(await response.text()))
}

/** Gerrit changes submitted together with this one, sorted by change number. */
async function fetchSubmittedTogether(changeNumber) {
  const url = `https://gerrit.wikimedia.org/r/changes/design%2Fcodex~${changeNumber}/submitted_together`
  const changes = await fetchJson(url)
  if (!Array.isArray(changes)) {
    throw new Error('Gerrit submitted_together response was not an array.')
  }
  const sorted = [...changes].sort((a, b) => a._number - b._number)
  return sorted.map((entry) => {
    const number = String(entry._number)
    return {
      change: number,
      subject: entry.subject ?? '',
      url: `https://gerrit.wikimedia.org/r/c/design/codex/+/${number}`,
    }
  })
}

function computePatchRef(changeNumber, patchsetNumber) {
  const twoDigit = changeNumber.slice(-2).padStart(2, '0')
  return `refs/changes/${twoDigit}/${changeNumber}/${patchsetNumber}`
}

function installedVersion(pkg) {
  const p = path.join(installedPackageDir(pkg), 'package.json')
  return JSON.parse(fs.readFileSync(p, 'utf8')).version
}

// Resolve the commit the installed published Codex was built from, so the diff
// we emit is layered onto a baseline that matches the published artifact. We
// prefer the release tag for the installed version (its build == what shipped to
// npm, so the 3-way merge sees base ~= current and lands cleanly). When no such
// tag exists we fall back to merge-base(change, origin/main) — the newest merged
// ancestor beneath the change — which is correct for a change based at/near the
// release but can miss commits that landed between the release and the change's
// own base.
function resolveBaselineSha(version, changeSha) {
  for (const tag of [`v${version}`, version]) {
    const res = tryRun('git', ['rev-parse', '--verify', '--quiet', `refs/tags/${tag}^{commit}`], {
      cwd: CODEX_REPO_DIR,
    })
    if (res.status === 0 && res.stdout.trim()) {
      console.log(`Baseline: release tag ${tag} (${res.stdout.trim().slice(0, 10)})`)
      return res.stdout.trim()
    }
  }
  console.warn(
    `Could not resolve a release tag for Codex ${version}; ` +
      'falling back to merge-base(change, origin/main).',
  )
  return run('git', ['merge-base', changeSha, 'origin/main'], { cwd: CODEX_REPO_DIR })
}

function isGitRepo(dir) {
  return (
    tryRun('git', ['rev-parse', '--git-dir'], { cwd: dir }).status === 0 &&
    fs.existsSync(path.join(dir, '.git'))
  )
}

function ensureRepo() {
  fs.mkdirSync(CACHE_ROOT, { recursive: true })
  if (fs.existsSync(CODEX_REPO_DIR) && !isGitRepo(CODEX_REPO_DIR)) {
    console.warn(
      `Removing invalid Codex cache at ${CODEX_REPO_DIR} (not a git repository).`,
    )
    fs.rmSync(CODEX_REPO_DIR, { recursive: true, force: true })
  }
  if (!fs.existsSync(CODEX_REPO_DIR)) {
    console.log(`Cloning design/codex into ${CODEX_REPO_DIR}`)
    run('git', ['clone', '--filter=blob:none', GERRIT_REPO, CODEX_REPO_DIR], { cwd: CACHE_ROOT })
  } else {
    run('git', ['remote', 'set-url', 'origin', GERRIT_REPO], { cwd: CODEX_REPO_DIR })
  }
}

function installCodexDeps() {
  console.log('Installing Codex build dependencies')
  const ci = tryRun('npm', ['ci', '--ignore-scripts'], { cwd: CODEX_REPO_DIR })
  if (ci.status !== 0) {
    console.warn('npm ci failed; falling back to npm install --ignore-scripts')
    run('npm', ['install', '--ignore-scripts'], { cwd: CODEX_REPO_DIR })
  }
}

function buildCodex() {
  for (const pkg of CODEX_BUILD_ORDER) {
    run('npm', ['run', 'build', '--workspace', pkg], { cwd: CODEX_REPO_DIR })
  }
}

// Collect every distributed build artifact of the installed Codex packages:
// everything under `dist/**` plus the root `theme-*` token files. Patching the
// full distribution (rather than only the files ProtoWiki imports today) keeps
// the patched node_modules self-contained — any current or future import sees
// the change, with no need to re-run when ProtoWiki's imports change. Package
// metadata (package.json / README / LICENSE) is deliberately excluded.
function collectCandidates() {
  const candidates = []

  for (const pkg of CODEX_PACKAGES) {
    const pkgRoot = installedPackageDir(pkg)
    if (!fs.existsSync(pkgRoot)) continue
    const buildPkgDir = path.join(CODEX_REPO_DIR, PACKAGE_DIRS.get(pkg))

    const add = (rel) => {
      const installedFile = path.join(pkgRoot, rel)
      if (!isFormattable(installedFile)) return
      // Token theme files ship at the package root but are built into dist/.
      const buildRel =
        !rel.includes('/') && rel.startsWith('theme-') ? path.join('dist', rel) : rel
      candidates.push({
        target: `${pkg}/${rel}`,
        pkg,
        rel,
        installedFile,
        buildFile: path.join(buildPkgDir, buildRel),
      })
    }

    const distDir = path.join(pkgRoot, 'dist')
    if (fs.existsSync(distDir)) {
      const walk = (dir) => {
        for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
          const abs = path.join(dir, entry.name)
          if (entry.isDirectory()) {
            walk(abs)
          } else if (entry.isFile()) {
            add(path.relative(pkgRoot, abs))
          }
        }
      }
      walk(distDir)
    }

    for (const entry of fs.readdirSync(pkgRoot, { withFileTypes: true })) {
      if (entry.isFile() && entry.name.startsWith('theme-')) {
        add(entry.name)
      }
    }
  }

  return candidates
}

function snapshotBuild(candidates) {
  const map = new Map()
  for (const candidate of candidates) {
    if (fs.existsSync(candidate.buildFile)) {
      map.set(candidate.target, fs.readFileSync(candidate.buildFile, 'utf8'))
    }
  }
  return map
}

// 3-way merge: layer the base->other change onto current, returning the merged
// text. Throws on conflict so we never emit a wrong patch silently.
function mergeThreeWay(rel, current, base, other) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'codex-merge-'))
  try {
    const cur = path.join(tmp, 'current')
    const bse = path.join(tmp, 'base')
    const oth = path.join(tmp, 'other')
    fs.writeFileSync(cur, current)
    fs.writeFileSync(bse, base)
    fs.writeFileSync(oth, other)
    const res = tryRun('git', ['merge-file', '-p', cur, bse, oth])
    if (res.status === 0) return res.stdout
    if (res.status > 0) {
      throw new Error(
        `Could not cleanly merge the change into the published ${rel} ` +
          '(the change overlaps with version differences). Try a newer patchset or re-run.',
      )
    }
    throw new Error(`git merge-file failed for ${rel}: ${res.stderr}`)
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true })
  }
}

function patchDirHasFiles() {
  if (!fs.existsSync(PATCH_DIR)) return false
  return fs.readdirSync(PATCH_DIR).some(
    (file) => file === 'manifest.json' || file.endsWith('.patch'),
  )
}

function removePatchFiles() {
  if (!fs.existsSync(PATCH_DIR)) return
  for (const file of fs.readdirSync(PATCH_DIR)) {
    if (file === 'manifest.json' || file.endsWith('.patch')) {
      fs.rmSync(path.join(PATCH_DIR, file))
    }
  }
}

async function makePatch(changeInput) {
  const changeNumber = parseChangeNumber(changeInput)
  console.log(`Fetching Gerrit change ${changeNumber}`)
  const detailUrl = `https://gerrit.wikimedia.org/r/changes/design%2Fcodex~${changeNumber}/detail`
  const detail = await fetchJson(detailUrl)
  const stackedChanges = await fetchSubmittedTogether(changeNumber)
  const stackedChangeCount = Math.max(0, stackedChanges.length - 1)
  if (stackedChangeCount > 0) {
    console.log(`Submitted together: ${stackedChanges.length} change(s) (+${stackedChangeCount} stacked)`)
  }
  const patchset = detail.current_revision_number
  if (!patchset) {
    throw new Error('Gerrit response did not include current_revision_number')
  }
  const ref = computePatchRef(changeNumber, String(patchset))
  console.log(`Current patchset: ${patchset} (${ref})`)

  // 1. Establish a pristine published baseline in node_modules.
  await ensureCodex(false)
  const outDir = PATCH_DIR
  removePatchFiles()
  const versions = Object.fromEntries(CODEX_PACKAGES.map((pkg) => [pkg, installedVersion(pkg)]))
  console.log(`Baseline Codex version: ${versions['@wikimedia/codex']}`)

  // 2. Fetch the change and resolve the published baseline the diff lands on.
  ensureRepo()
  run('git', ['fetch', 'origin', ref], { cwd: CODEX_REPO_DIR })
  const changeSha = run('git', ['rev-parse', 'FETCH_HEAD'], { cwd: CODEX_REPO_DIR })
  // Baseline against the commit the installed published Codex was built from (its
  // release tag), so the emitted diff spans published -> change: every change
  // needed to ship this patch on top of the published package, including commits
  // that landed on main between the release and the change's own base. This lets
  // a change stacked ahead of the latest release still apply cleanly onto the
  // published artifact CI installs, instead of capturing only the change's delta
  // from an unpublished ancestor (which would conflict on files that drifted
  // between the release and that ancestor).
  run('git', ['fetch', 'origin', 'main', '--tags'], { cwd: CODEX_REPO_DIR })
  const baselineSha = resolveBaselineSha(versions['@wikimedia/codex'], changeSha)

  // 3. Build the unpatched published baseline and the patched change.
  const candidates = collectCandidates()

  console.log('Building Codex at the published baseline (unpatched)')
  run('git', ['checkout', '--force', '--detach', baselineSha], { cwd: CODEX_REPO_DIR })
  installCodexDeps()
  buildCodex()
  const unpatched = snapshotBuild(candidates)

  console.log('Building Codex at the change commit (patched)')
  run('git', ['checkout', '--force', '--detach', changeSha], { cwd: CODEX_REPO_DIR })
  buildCodex()
  const patched = snapshotBuild(candidates)

  // 4. The change's true footprint: files that differ between the two builds.
  const changed = candidates.filter((candidate) => {
    const before = unpatched.get(candidate.target)
    const after = patched.get(candidate.target)
    return before !== undefined && after !== undefined && before !== after
  })

  if (changed.length === 0) {
    throw new Error('The change produced no differences in any distributed Codex file.')
  }

  // 5. For each changed file, layer the change onto the published file (after
  // formatting, so the minified single-line CSS diffs by content not file size).
  const prettier = await loadPrettier()
  const jsdiff = await loadJsDiff()
  const prettierOpts = readPrettierOptions()

  fs.mkdirSync(outDir, { recursive: true })
  const manifestFiles = []

  for (const candidate of changed) {
    const published = fs.readFileSync(candidate.installedFile, 'utf8')
    const fmtPublished = await formatContent(prettier, published, candidate.rel, prettierOpts)
    const fmtBase = await formatContent(
      prettier,
      unpatched.get(candidate.target),
      candidate.rel,
      prettierOpts,
    )
    const fmtOther = await formatContent(
      prettier,
      patched.get(candidate.target),
      candidate.rel,
      prettierOpts,
    )

    const merged = mergeThreeWay(candidate.rel, fmtPublished, fmtBase, fmtOther)
    const fmtMerged = await formatContent(prettier, merged, candidate.rel, prettierOpts)
    if (fmtMerged === fmtPublished) continue

    const diff = jsdiff.createPatch(candidate.rel, fmtPublished, fmtMerged, '', '')
    const fileName = patchFileName(candidate.target)
    fs.writeFileSync(path.join(outDir, fileName), diff)
    manifestFiles.push({
      target: candidate.target,
      package: candidate.pkg,
      rel: candidate.rel,
      patch: fileName,
      // Content hashes of the formatted baseline and patched result, so the
      // applier can apply (and skip re-applying) deterministically.
      baseSha: sha256(fmtPublished),
      patchedSha: sha256(fmtMerged),
    })
    console.log(`  patched ${candidate.target}`)
  }

  if (manifestFiles.length === 0) {
    throw new Error('No effective changes remained after merging into the published files.')
  }

  const manifest = {
    subject: detail.subject,
    url: `https://gerrit.wikimedia.org/r/c/design/codex/+/${changeNumber}`,
    change: changeNumber,
    patchset,
    revision: changeSha,
    baseline: baselineSha,
    stackedChanges,
    stackedChangeCount,
    generatedAt: new Date().toISOString(),
    codexVersions: versions,
    prettierVersion: prettierVersion(prettier),
    files: manifestFiles,
  }
  fs.writeFileSync(path.join(outDir, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`)

  // 6. Apply locally via the same path CI uses.
  console.log('Applying patch locally')
  await ensureCodex(true)
  clearViteCache()

  console.log(`\nWrote ${manifestFiles.length} patch file(s) to patches/codex/.`)
  console.log('Commit patches/codex/ so deploys and PR previews reproduce the change.')
  console.log('Remove it with: npm run codex:reset')
}

async function reset() {
  const hadPatchFiles = patchDirHasFiles()
  const hadMarker = Boolean(readPatchMarker())
  if (!hadPatchFiles && !hadMarker) {
    console.log('No patch in patches/codex/; nothing to remove.')
    return
  }
  await ensureCodex(false)
  if (hadPatchFiles) {
    removePatchFiles()
  }
  clearViteCache()
  console.log('Removed the Codex patch. Installs and deploys are stock Codex again.')
}

async function main() {
  const args = process.argv.slice(2)
  if (args[0] === '--reset') {
    await reset()
    return
  }
  if (!args[0]) {
    console.log('Usage:')
    console.log('  npm run codex:patch -- <gerrit-url-or-change-number>')
    console.log('  npm run codex:reset')
    process.exit(1)
  }
  await makePatch(args[0])
}

main().catch((error) => {
  console.error(error instanceof Error ? error.message : String(error))
  process.exit(1)
})
