<script setup lang="ts">
import { computed, nextTick, ref } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { CdxButton, CdxIcon } from '@wikimedia/codex'
import {
  cdxIconAppearance,
  cdxIconBell,
  cdxIconBookmarkList,
  cdxIconDownTriangle,
  cdxIconMenu,
  cdxIconSearch,
  cdxIconTray,
  cdxIconUserAvatar,
  cdxIconWatchlist,
} from '@wikimedia/codex-icons'

import AppearanceSettingsPanel from '@/components/settings/AppearanceSettingsPanel.vue'
import SettingsPopover from '@/components/settings/SettingsPopover.vue'
import UserSettingsPanel from '@/components/settings/UserSettingsPanel.vue'
import { useChromeSearchHandlers } from '@/composables/useChromeSearch'
import { useConfig } from '@/composables/useConfig'
import { useWordmarkMainPageLink } from '@/composables/useWordmarkMainPageLink'
import { DEFAULT_CHROME_NAV_TOOLS, type ChromeNavTool } from './headerNavTools'
import { globalTheme } from '@/theme'
import type { Theme } from '@/theme'
import { preservedQueryFromLocationQuery } from '@/appearance/url-query'
import Search, { type SearchSubmitPayload } from '../Search.vue'

const chromeSearchHandlers = useChromeSearchHandlers()
const wordmarkMainPageLink = useWordmarkMainPageLink()

const { user } = useConfig()

/** Fallback EN CDN SVGs — override via **`wordmarkSrc`** / **`taglineSrc`**. */
const WIKIPEDIA_WORDMARK_EN =
  'https://en.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en-25.svg'
const WIKIPEDIA_TAGLINE_EN =
  'https://en.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-en-25.svg'

interface Props {
  /** Local theme override. Sets `data-theme` on the root. */
  theme?: Theme
  /**
   * Meta link mock before tool icons; trim; empty hides unless **`#username`** overrides.
   */
  username?: string
  /** Stacked wordmark image URL (`#logo` replaces both lines). */
  wordmarkSrc?: string
  /** Tagline image URL beneath the wordmark. */
  taglineSrc?: string
  /**
   * Subset/order of mocked Vector tool icons.
   * **`#nav`** replaces the whole cluster regardless.
   */
  navTools?: ChromeNavTool[]
  /**
   * When true, appearance and user tools open prototyping settings; wordmark links to the Main Page.
   */
  prototypingSettings?: boolean
  /** When set, desktop bookmark tool links here (web template cluster). */
  savedPagesRoute?: string
}

const props = withDefaults(defineProps<Props>(), {
  theme: undefined,
  username: undefined,
  wordmarkSrc: undefined,
  taglineSrc: undefined,
  navTools: undefined,
  prototypingSettings: true,
  savedPagesRoute: undefined,
})

const route = useRoute()
const router = useRouter()

const effectiveTheme = computed<Theme>(() => props.theme ?? globalTheme.value)

/*
 * Below 1120px the search box folds into an icon. Like Vector 2022, the icon
 * opens the box in place of the menu and wordmark, and it folds again on
 * Escape or when focus leaves it.
 */
const searchOpen = ref(false)
const inlineSearch = ref<HTMLElement | null>(null)

async function openSearch(): Promise<void> {
  searchOpen.value = true
  await nextTick()
  inlineSearch.value?.querySelector('input')?.focus()
}

function onSearchFocusOut(event: FocusEvent): void {
  if (!inlineSearch.value?.contains(event.relatedTarget as Node | null)) searchOpen.value = false
}
const trimmedUsername = computed(() => (props.username ?? '').trim())
const showChromeUsernameLink = computed(() => trimmedUsername.value.length > 0)
const isLoggedOut = computed(() => user.value === 'logged-out')

const desktopWordmarkSrc = computed(() => props.wordmarkSrc ?? WIKIPEDIA_WORDMARK_EN)
const desktopTaglineSrc = computed(() => props.taglineSrc ?? WIKIPEDIA_TAGLINE_EN)

const effectiveNavTools = computed(() =>
  props.navTools?.length ? props.navTools : DEFAULT_CHROME_NAV_TOOLS,
)

function navHas(tool: ChromeNavTool): boolean {
  return effectiveNavTools.value.includes(tool)
}

function handleSearchSelect(title: string) {
  chromeSearchHandlers?.onSelect?.(title)
}

function handleSearchSubmit(payload: SearchSubmitPayload) {
  chromeSearchHandlers?.onSubmit?.(payload)
}

const savedPagesTo = computed(() => {
  if (!props.savedPagesRoute?.length) return null
  return {
    path: props.savedPagesRoute,
    query: preservedQueryFromLocationQuery(route.query),
  }
})

function goToSavedPages(): void {
  const location = savedPagesTo.value
  if (!location) return
  void router.push(location)
}
</script>

<template>
  <header
    class="vector-chrome-header"
    :class="{ 'vector-chrome-header--search-open': searchOpen }"
    data-skin="desktop"
    :data-theme="effectiveTheme"
  >
    <nav class="vector-chrome-header__nav" aria-label="Site">
      <div class="vector-chrome-header__start">
        <slot name="menu">
          <!-- Mock only — not interactive (FakeMediaWiki uses bare chrome / icon affordances). -->
          <span class="vector-chrome-header__menu-icon" aria-hidden="true">
            <CdxIcon :icon="cdxIconMenu" />
          </span>
        </slot>

        <component
          :is="props.prototypingSettings ? RouterLink : 'span'"
          class="vector-chrome-header__brand-link"
          v-bind="
            props.prototypingSettings
              ? { to: wordmarkMainPageLink, 'aria-label': 'Visit the main page' }
              : {}
          "
        >
          <slot name="logo">
            <span class="vector-chrome-header__wordmarks">
              <img
                class="vector-chrome-header__wordmark-img"
                :src="desktopWordmarkSrc"
                width="120"
                height="18"
                alt="Wikipedia"
              />
              <img
                class="vector-chrome-header__tagline-img"
                :src="desktopTaglineSrc"
                width="120"
                height="14"
                alt=""
              />
            </span>
          </slot>
        </component>
      </div>

      <div
        ref="inlineSearch"
        class="vector-chrome-header__inline-search"
        @focusout="onSearchFocusOut"
        @keydown.esc="searchOpen = false"
      >
        <div class="vector-chrome-header__search">
          <Search
            use-button
            auto-expand-width
            @select="handleSearchSelect"
            @submit="handleSearchSubmit"
          />
        </div>
      </div>

      <div class="vector-chrome-header__end">
        <CdxButton
          class="vector-chrome-header__search-icon-toggle"
          weight="quiet"
          aria-label="Search"
          :aria-expanded="searchOpen"
          @click="openSearch"
        >
          <CdxIcon :icon="cdxIconSearch" />
        </CdxButton>
        <slot name="username">
          <SettingsPopover v-if="isLoggedOut && props.prototypingSettings">
            <template #default="{ openPopover }">
              <span class="vector-chrome-header__logged-out-toolbar">
                <a
                  class="vector-chrome-header__text-link"
                  href="#"
                  @click.prevent
                >
                  Donate
                </a>
                <a
                  class="vector-chrome-header__text-link"
                  href="#"
                  @click.prevent="openPopover($event)"
                >
                  Create account
                </a>
                <a
                  class="vector-chrome-header__text-link"
                  href="#"
                  @click.prevent="openPopover($event)"
                >
                  Log in
                </a>
              </span>
            </template>
            <template #panel="{ open: settingsOpen }">
              <UserSettingsPanel :settings-open="settingsOpen" />
            </template>
          </SettingsPopover>
          <div
            v-else-if="isLoggedOut"
            class="vector-chrome-header__logged-out-toolbar"
          >
            <a class="vector-chrome-header__text-link" href="#" @click.prevent>
              Donate
            </a>
            <a class="vector-chrome-header__text-link" href="#" @click.prevent>
              Create account
            </a>
            <a class="vector-chrome-header__text-link" href="#" @click.prevent>
              Log in
            </a>
          </div>
          <a
            v-else-if="showChromeUsernameLink"
            class="vector-chrome-header__text-link vector-chrome-header__username-display"
            href="#"
            @click.prevent
          >
            {{ trimmedUsername }}
          </a>
        </slot>
        <slot v-if="!isLoggedOut" name="nav">
          <SettingsPopover v-if="navHas('appearance') && props.prototypingSettings">
            <template #default="{ toggle, open }">
              <CdxButton
                weight="quiet"
                aria-label="Appearance"
                aria-haspopup="dialog"
                :aria-expanded="open"
                @click="toggle"
              >
                <CdxIcon :icon="cdxIconAppearance" />
              </CdxButton>
            </template>
            <template #panel>
              <AppearanceSettingsPanel :show-app-platform="false" />
            </template>
          </SettingsPopover>
          <CdxButton
            v-else-if="navHas('appearance')"
            weight="quiet"
            aria-label="Appearance"
          >
            <CdxIcon :icon="cdxIconAppearance" />
          </CdxButton>
          <CdxButton
            v-if="navHas('notifications')"
            weight="quiet"
            aria-label="Notifications"
          >
            <CdxIcon :icon="cdxIconBell" />
          </CdxButton>
          <CdxButton v-if="navHas('notices')" weight="quiet" aria-label="Notices">
            <CdxIcon :icon="cdxIconTray" />
          </CdxButton>
          <CdxButton
            v-if="navHas('bookmarks')"
            weight="quiet"
            :aria-label="savedPagesTo ? 'Saved pages' : 'Bookmarks'"
            @click="goToSavedPages"
          >
            <CdxIcon :icon="cdxIconBookmarkList" />
          </CdxButton>
          <CdxButton v-if="navHas('watchlist')" weight="quiet" aria-label="Watchlist">
            <CdxIcon :icon="cdxIconWatchlist" />
          </CdxButton>
          <div v-if="navHas('user')" class="vector-chrome-header__user-menu">
            <slot name="user-menu">
              <SettingsPopover v-if="props.prototypingSettings">
                <template #default="{ toggle, open }">
                  <CdxButton
                    weight="quiet"
                    aria-label="Mock user settings"
                    aria-haspopup="dialog"
                    :aria-expanded="open"
                    @click="toggle"
                  >
                    <CdxIcon :icon="cdxIconUserAvatar" />
                    <CdxIcon
                      class="vector-chrome-header__user-menu-caret"
                      :icon="cdxIconDownTriangle"
                      size="small"
                    />
                  </CdxButton>
                </template>
                <template #panel="{ open: settingsOpen }">
                  <UserSettingsPanel :settings-open="settingsOpen" />
                </template>
              </SettingsPopover>
              <CdxButton v-else weight="quiet" aria-label="User menu" aria-haspopup="menu">
                <CdxIcon :icon="cdxIconUserAvatar" />
                <CdxIcon
                  class="vector-chrome-header__user-menu-caret"
                  :icon="cdxIconDownTriangle"
                  size="small"
                />
              </CdxButton>
            </slot>
          </div>
        </slot>
      </div>
    </nav>
  </header>
</template>

<style scoped>
.vector-chrome-header {
  background-color: var(--background-color-base, #fff);
}

.vector-chrome-header__search {
  min-width: 0;
}

.vector-chrome-header__wordmark-img,
.vector-chrome-header__tagline-img {
  display: block;
  width: auto;
  max-width: 100%;
}

/*
 * Breakpoint parity with FakeMediaWiki `src/views/SpecialView/style.css`:
 * - max-width 1120px — collapse inline search → icon (nav-item-search / nav-button-search).
 * Skin swap (nav-desktop vs nav-mobile) stays at 640px via src/theme.ts.
 */

.vector-chrome-header__nav {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--spacing-100, 16px);
  min-height: 66px;
  padding: var(--spacing-50, 8px) var(--spacing-100, 16px);
}

.vector-chrome-header__start {
  display: flex;
  align-items: center;
  gap: var(--spacing-50, 8px);
}

.vector-chrome-header__menu-icon {
  display: inline-flex;
  flex-shrink: 0;
  align-items: center;
  justify-content: center;
  min-width: var(--size-icon-medium, 32px);
  min-height: var(--size-icon-medium, 32px);
  margin: 0;
  padding: var(--spacing-25, 4px);
  padding-inline-start: var(--spacing-50, 8px);
  border: none;
  background: transparent;
  color: var(--color-base, #202122);
  line-height: 0;
  cursor: default;
  pointer-events: none;
}

.vector-chrome-header :slotted(.chrome-header__menu-btn) {
  flex-shrink: 0;
  min-width: var(--size-icon-medium, 32px);
  height: var(--size-icon-medium, 32px);
  margin: 0;
  padding: var(--spacing-25, 4px);
  padding-inline-start: var(--spacing-50, 8px);
}

.vector-chrome-header__menu-icon :deep(svg) {
  display: block;
}

.vector-chrome-header__brand-link {
  display: flex;
  align-items: center;
  text-decoration: none;
  color: inherit;
}

.vector-chrome-header__brand-link:hover {
  text-decoration: none;
  color: inherit;
}

.vector-chrome-header__wordmarks {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 2px;
  padding-block: 3px;
  padding-inline-start: var(--spacing-75, 12px);
  margin-inline-start: var(--spacing-50, 8px);
  width: 152px;
  min-height: 44px;
}

.vector-chrome-header__inline-search {
  display: flex;
  flex: 1 1 auto;
  align-items: stretch;
  gap: 0;
  max-width: 474px;
  padding-inline-start: var(--spacing-150, 24px);
}

.vector-chrome-header__inline-search .vector-chrome-header__search {
  flex: 1;
  min-width: 0;
  max-width: 32rem;
}

.vector-chrome-header__search-icon-toggle {
  display: none;
}

.vector-chrome-header__end {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 0.2rem;
  margin-inline-start: auto;
}

.vector-chrome-header__logged-out-toolbar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--spacing-75, 12px);
  margin-inline: var(--spacing-8, 8px);
}

.vector-chrome-header__text-link {
  color: var(--color-progressive, #36c);
  font-size: var(--font-size-small, 14px);
  font-weight: normal;
  line-height: 1.4;
  text-decoration: none;
}

a.vector-chrome-header__text-link:hover {
  text-decoration: underline;
}

.vector-chrome-header__username-display {
  margin-inline: var(--spacing-8, 8px);
}

.vector-chrome-header__end .cdx-button {
  min-width: var(--size-icon-medium, 32px);
  height: var(--size-icon-medium, 32px);
  padding: 0.5rem 0.4rem;
}

.vector-chrome-header__user-menu .cdx-button {
  display: inline-flex;
  align-items: center;
  gap: 0;
  min-width: calc(var(--size-icon-medium, 32px) + 0.75rem);
  padding-inline-end: 0.25rem;
}

.vector-chrome-header__user-menu-caret {
  flex-shrink: 0;
  margin-inline-start: -0.125rem;
}

.vector-chrome-header[data-theme='dark'] .vector-chrome-header__wordmark-img,
.vector-chrome-header[data-theme='dark'] .vector-chrome-header__tagline-img {
  opacity: 0;
}

@media (max-width: 1120px) {
  .vector-chrome-header__inline-search {
    display: none;
  }

  /*
   * Opened from the icon: like Vector 2022, the search box takes the place of
   * the menu and wordmark (and its own icon); the user tools stay.
   */
  .vector-chrome-header--search-open .vector-chrome-header__inline-search {
    display: flex;
  }

  /* Ends where the icon was and grows leftwards over all the freed space. */
  .vector-chrome-header--search-open .vector-chrome-header__inline-search,
  .vector-chrome-header--search-open .vector-chrome-header__inline-search .vector-chrome-header__search {
    max-width: none;
  }

  /* A zero basis, so the box takes what the tools leave rather than pushing them to a new row. */
  .vector-chrome-header--search-open .vector-chrome-header__inline-search {
    flex: 1 1 0;
    min-width: 0;
    padding-inline-start: 0;
  }

  /*
   * CODEX+ CdxTextInput has a 256px min-width; in a narrow header the field
   * would run under the Search button. Let it shrink with the box.
   */
  .vector-chrome-header--search-open :deep(.cdx-search-input__input-wrapper),
  .vector-chrome-header--search-open :deep(.cdx-search-input__text-input) {
    min-width: 0;
  }

  /* The tools' own gap, so the box's end lines up with the icon's. */
  .vector-chrome-header--search-open .vector-chrome-header__nav {
    column-gap: 0.2rem;
  }

  .vector-chrome-header--search-open .vector-chrome-header__start,
  .vector-chrome-header--search-open .vector-chrome-header__search-icon-toggle {
    display: none;
  }

  .vector-chrome-header__search-icon-toggle {
    display: inline-flex;
  }

  .vector-chrome-header__end .cdx-button {
    height: var(--size-icon-large, 40px);
    width: var(--size-icon-large, 40px);
    padding: 0.7rem;
  }

  .vector-chrome-header__user-menu .cdx-button {
    width: auto;
    min-width: calc(var(--size-icon-large, 40px) + 0.75rem);
  }
}
</style>
