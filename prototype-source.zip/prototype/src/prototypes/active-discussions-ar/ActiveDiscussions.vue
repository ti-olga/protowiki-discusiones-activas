<script setup>
import { cdxIconPushPinFilled, prototypeIconFunnelFilled } from './icons'
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import {
  CdxButton,
  CdxCheckbox,
  CdxDialog,
  CdxField,
  CdxIcon,
  CdxMenuButton,
  CdxMessage,
  CdxMultiselectLookup,
  CdxProgressBar,
  CdxToast,
  CdxToggleButtonGroup,
} from '@wikimedia/codex'
import {
  cdxIconEllipsis,
  cdxIconBell,
  cdxIconCollapse,
  cdxIconPrevious,
  cdxIconConfigure,
  cdxIconInfo,
  cdxIconClose,
} from '@wikimedia/codex-icons'
import DiscussionCard from './DiscussionCard.vue'
import {
  state,
  current,
  pinned,
  subscribed,
  ordered,
  resetLimit,
  toggleSaved,
  ensureLoaded,
  loadDiscussions,
} from './discussionStore'
import { groups, WIKI_ORIGIN } from './discussionData'
const props = defineProps({ fullQueue: { type: Boolean, default: false } })
const router = useRouter(),
  mobile = ref(innerWidth < 800)
const updateViewport = () => (mobile.value = innerWidth < 800)
onMounted(() => {
  addEventListener('resize', updateViewport)
  ensureLoaded()
})
onUnmounted(() => {
  removeEventListener('resize', updateViewport)
  clearTimeout(searchTimer)
  searchController?.abort()
})
const mainList = ordered
const visible = computed(() =>
  props.fullQueue ? mainList.value : mainList.value.slice(0, state.limit),
)
const canShowMore = computed(() => !props.fullQueue && visible.value.length < mainList.value.length)
const toggles = computed(() => [
  { value: 'all', label: 'الكل', ariaLabel: 'كل النقاشات' },
  { value: 'pinned', label: 'المثبتة', ariaLabel: 'النقاشات المثبتة: ' + pinned.value.length },
  {
    value: 'subscribed',
    label: 'المشترك بها',
    ariaLabel: 'النقاشات المشترك بها: ' + subscribed.value.length,
  },
])
const overflowItems = computed(() => [
  {
    value: 'interests',
    label: 'الاهتمامات',
    description:
      state.interests.length + (state.interests.length === 1 ? ' محدد' : ' محددة'),
    icon: cdxIconConfigure,
  },
  { value: 'about', label: 'حول النقاشات النشطة', icon: cdxIconInfo },
])
const dialog = ref(''),
  draftTypes = ref([]),
  draftInterests = ref([]),
  inputChips = ref([]),
  interestOptions = ref([]),
  lookupValue = ref('')
function setting(value) {
  if (value === 'types') draftTypes.value = [...state.types]
  if (value === 'interests') {
    draftInterests.value = [...state.interests]
    inputChips.value = state.interests.map((value) => ({ value, label: value }))
    interestOptions.value = state.interests.map((value) => ({ value, label: value }))
  }
  dialog.value = value || ''
}
const dialogTitle = computed(
  () =>
    ({
      types: 'أنواع النقاشات',
      interests: 'الاهتمامات',
      about: 'حول النقاشات النشطة',
    })[dialog.value],
)
function clearInterests() {
  draftInterests.value = []
  inputChips.value = []
}
function saveFilters() {
  if (dialog.value === 'types') state.types = [...draftTypes.value]
  if (dialog.value === 'interests') state.interests = [...draftInterests.value]
  dialog.value = ''
  loadDiscussions()
}
let searchTimer,
  searchController,
  searchGeneration = 0
watch(lookupValue, (value) => {
  clearTimeout(searchTimer)
  searchController?.abort()
  const generation = ++searchGeneration
  if (!String(value).trim()) {
    interestOptions.value = []
    return
  }
  searchTimer = setTimeout(async () => {
    try {
      searchController = new AbortController()
      const url = new URL('/w/api.php', WIKI_ORIGIN)
      url.search = new URLSearchParams({
        action: 'opensearch',
        search: String(value),
        limit: '10',
        namespace: '0',
        format: 'json',
        origin: '*',
      })
      const response = await fetch(url, { signal: searchController.signal })
      const result = await response.json()
      if (generation === searchGeneration)
        interestOptions.value = result[1].map((value) => ({ value, label: value }))
    } catch (error) {
      if (error.name !== 'AbortError') interestOptions.value = []
    }
  }, 250)
})
watch(() => current.value.view, resetLimit)
const toast = ref(null)
function confirmation(title, body, link = false) {
  toast.value = { id: Date.now(), title, body, link }
}
function pin(d, deferRemoval = false) {
  toggleSaved('pins', d, deferRemoval)
}
function subscribe(d, deferRemoval = false) {
  toggleSaved('subscriptions', d, deferRemoval)
}
function preference(d, delta) {
  state.preferences[d.url] = (state.preferences[d.url] || 0) + delta
  confirmation(
    'حُدّثت التفضيلات',
    delta > 0
      ? 'ستظهر نقاشات أكثر من هذا النوع.'
      : 'ستظهر نقاشات أقل من هذا النوع.',
  )
}
function more() {
  if (mobile.value) {
    router.push('/active-discussions-ar/cola')
    return
  }
  state.expanded = true
  state.limit = state.limit === 3 ? 10 : state.limit + 10
}
const emptyCopy = computed(() =>
  current.value.view === 'pinned'
    ? 'لم تثبّت أي نقاش بعد. استخدم قائمة البطاقة لتثبيت نقاش.'
    : current.value.view === 'subscribed'
      ? 'لم تشترك في أي نقاش بعد. استخدم قائمة البطاقة للاشتراك.'
      : 'لا توجد نقاشات تطابق هذه المرشحات. جرّب اهتمامات أو أنواع نقاشات أخرى.',
)
</script>
<template>
  <section
    class="active-discussions"
    :class="{ 'active-discussions--queue': fullQueue }"
    data-version="B"
  >
    <div class="active-discussions__header">
      <CdxButton
        v-if="fullQueue"
        weight="quiet"
        :icon-only="true"
        aria-label="العودة إلى البداية"
        @click="router.push('/active-discussions-ar')"
        ><CdxIcon :icon="cdxIconPrevious"
      /></CdxButton>
      <h2>النقاشات النشطة</h2>
      <div class="active-discussions__settings">
        <CdxButton
          class="active-discussions__filter"
          weight="quiet"
          :icon-only="true"
          :aria-label="
            'ترشيح أنواع النقاشات: ' +
            state.types.length +
            (state.types.length === 1 ? ' محدد' : ' محددة')
          "
          @click="setting('types')"
          ><span class="active-discussions__filter-symbol"
            ><CdxIcon :icon="prototypeIconFunnelFilled" /><span
              v-if="state.types.length > 0"
              class="active-discussions__filter-count"
              aria-hidden="true"
              >{{ state.types.length }}</span
            ></span
          ></CdxButton
        >
        <CdxMenuButton
          :selected="null"
          :menu-items="overflowItems"
          weight="quiet"
          aria-label="خيارات النقاشات النشطة"
          @update:selected="setting"
          ><CdxIcon :icon="cdxIconEllipsis"
        /></CdxMenuButton>
      </div>
    </div>
    <div class="active-discussions__controls">
      <CdxToggleButtonGroup
        class="active-discussions__toggles"
        v-model="current.view"
        :buttons="toggles"
        aria-label="قائمة النقاشات"
      >
        <template #default="{ button }"
          ><template v-if="button.value === 'all'">الكل</template
          ><template v-else
            ><CdxIcon
              :icon="button.value === 'pinned' ? cdxIconPushPinFilled : cdxIconBell"
            /><span v-if="(button.value === 'pinned' ? pinned.length : subscribed.length) > 0">{{
              button.value === 'pinned' ? pinned.length : subscribed.length
            }}</span></template
          ></template
        >
      </CdxToggleButtonGroup>
    </div>
    <div class="active-discussions__feed">
      <CdxMessage v-if="state.error" type="notice"
        >{{ state.error }}
        <CdxButton weight="quiet" @click="loadDiscussions">إعادة المحاولة</CdxButton></CdxMessage
      >
      <div
        v-if="state.busy"
        class="active-discussions__loading"
        aria-busy="true"
        aria-label="جارٍ تحميل النقاشات"
        role="status"
      >
        <CdxProgressBar inline aria-label="جارٍ تحميل النقاشات" />
        <div v-for="n in 3" :key="n" class="active-discussions__skeleton" aria-hidden="true">
          <div />
        </div>
        <CdxButton class="active-discussions__more" disabled>إظهار المزيد</CdxButton>
      </div>
      <template v-else>
        <div class="active-discussions__cards">
          <DiscussionCard
            v-for="d in visible"
            :key="d.url"
            :discussion="d"
            @pin="pin"
            @subscribe="subscribe"
            @prefer="preference($event, 1)"
            @less="preference($event, -1)"
          />
        </div>
        <p v-if="!mainList.length" class="active-discussions__empty" role="status">
          {{ emptyCopy }}
        </p>
        <div v-if="!fullQueue" class="active-discussions__footer">
          <CdxButton v-if="canShowMore" class="active-discussions__more" @click="more"
            >إظهار المزيد</CdxButton
          >
          <CdxButton
            v-if="!mobile && state.expanded"
            weight="quiet"
            :icon-only="true"
            aria-label="طي النقاشات"
            @click="resetLimit"
            ><CdxIcon :icon="cdxIconCollapse"
          /></CdxButton>
        </div>
      </template>
    </div>
    <CdxDialog
      use-close-button
      close-button-label="إغلاق"
      :open="!!dialog"
      :title="dialogTitle || 'النقاشات النشطة'"
      :primary-action="
        dialog === 'about' ? undefined : { label: 'تطبيق', actionType: 'progressive' }
      "
      :default-action="{ label: dialog === 'about' ? 'إغلاق' : 'إلغاء' }"
      @update:open="
        (value) => {
          if (!value) dialog = ''
        }
      "
      @primary="saveFilters"
      @default="dialog = ''"
    >
      <template v-if="dialog === 'types'"
        >
        <CdxField v-for="[group, items] in groups" :key="group" is-fieldset class="discussion-filter-group">
          <template #label>{{ group }}</template>
          <CdxCheckbox
            v-for="[type, description] in items"
            :key="type"
            v-model="draftTypes"
            :input-value="type"
            >{{ type }}<template #description>{{ description }}</template></CdxCheckbox
          >
        </CdxField></template
      >
      <CdxField v-else-if="dialog === 'interests'"
        ><template #label>الاهتمامات</template
        ><template #description
          >ابحث عن مقالات أو مواضيع. اترك الحقل فارغًا لتضمين جميع الاهتمامات.</template
        ><CdxMultiselectLookup
          v-model:selected="draftInterests"
          v-model:input-chips="inputChips"
          v-model:input-value="lookupValue"
          :menu-items="interestOptions"
          placeholder="ابحث في ويكيبيديا"
          aria-label="البحث عن اهتمامات"
          ><template #no-results>لم يُعثر على نتائج.</template></CdxMultiselectLookup
        ><CdxButton weight="quiet" @click="clearInterests">مسح الكل</CdxButton></CdxField
      >
      <p v-else>
        استكشف نقاشات ويكيبيديا العربية خلال آخر 30 يومًا. ثبّت المواضيع للعودة إليها لاحقًا واشترك لمتابعة التعليقات الجديدة.
      </p>
    </CdxDialog>
    <CdxToast
      v-if="toast"
      :key="toast.id"
      type="success"
      :auto-dismiss="toast.link ? 12000 : 6000"
      standalone
      prevent-user-dismiss
      @user-dismissed="toast = null"
      @auto-dismissed="toast = null"
      ><div class="spanish-toast-heading">
        <strong>{{ toast.title }}</strong
        ><CdxButton weight="quiet" :icon-only="true" aria-label="إغلاق" @click="toast = null"
          ><CdxIcon :icon="cdxIconClose"
        /></CdxButton>
      </div>
      <p>
        {{ toast.body }}
        <a
          v-if="toast.link"
          class="discussion-subscriptions-link"
          href="https://ar.wikipedia.org/wiki/Special:TopicSubscriptions?uselang=ar"
          target="_blank"
          rel="noopener"
          >فتح جميع المواضيع المشترك بها.</a
        >
      </p></CdxToast
    >
  </section>
</template>
<style scoped>
.active-discussions {
  min-width: 0;
  color: var(--color-base);
}
.active-discussions__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.active-discussions__header h2 {
  margin: 0;
  padding: 0;
  font: var(--font-weight-bold) var(--font-size-x-large)/var(--line-height-x-large)
    var(--font-family-system-sans);
}
.active-discussions__settings {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}
.active-discussions__filter {
  position: relative;
  overflow: visible;
  width: 32px;
  min-width: 32px;
  height: 32px;
  padding: 5px;
}
.active-discussions__filter-symbol {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 20px;
  height: 20px;
}
.active-discussions__filter-count {
  position: absolute;
  inset-inline-end: 0;
  bottom: 0;
  transform: translate(-40%, 35%);
  pointer-events: none;
  z-index: 2;
  box-sizing: border-box;
  min-width: 15px;
  height: 14px;
  padding: 0 2px;
  border: 1px solid var(--border-color-progressive);
  border-radius: 2px;
  background: var(--background-color-progressive-subtle);
  color: var(--color-progressive);
  font: 700 11px/12px var(--font-family-system-sans);
}
.active-discussions__controls {
  margin: 8px 0;
}
.active-discussions__select {
  width: 200px;
  max-width: 100%;
  margin: 12px 0;
}
.active-discussions[data-version='A'] .active-discussions__feed {
  margin-top: 12px;
}
.active-discussions__cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
}
.active-discussions__pinned {
  margin-bottom: 8px;
}
.active-discussions__empty {
  margin: 0;
  padding: 24px 0;
  color: var(--color-subtle);
  font-size: var(--font-size-medium);
}
.active-discussions__loading {
  display: flex;
  flex-direction: column;
  gap: 8px;
  position: relative;
}
.active-discussions__skeleton {
  height: 112px;
  padding: 12px;
  border: 1px solid var(--border-color-subtle);
  box-sizing: border-box;
}
.active-discussions__skeleton > div {
  height: 86px;
  width: 86px;
  border: 1px solid var(--border-color-subtle);
}
.active-discussions__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 8px;
}
.active-discussions__more {
  align-self: flex-start;
}
.discussion-filter-group {
  margin-block: var(--spacing-150);
}
.active-discussions--queue .active-discussions__header {
  height: 48px;
}
.active-discussions--queue .active-discussions__header h2 {
  font-size: var(--font-size-medium);
  text-align: center;
  flex: 1;
}
@media (max-width: 799px) {
  .active-discussions__more {
    width: 100%;
  }
  .active-discussions__footer {
    gap: 8px;
  }
  .active-discussions__header h2 {
    font-size: var(--font-size-large);
  }
}
.discussion-subscriptions-link {
  text-decoration: none;
}
.active-discussions--queue .active-discussions__header {
  position: relative;
  border-bottom: 1px solid var(--border-color-subtle);
}
.active-discussions--queue .active-discussions__header h2 {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  white-space: nowrap;
  pointer-events: none;
}
.active-discussions--queue .active-discussions__settings {
  margin-inline-start: auto;
}
/* Preserve the reviewed 8px accordion padding and card spacing. */
.active-discussions__pinned :deep(summary) {
  padding: 8px;
}
.active-discussions__pinned :deep(.cdx-accordion__content) {
  padding: 8px 0 0;
}

.active-discussions__toggles {
  display: inline-flex;
  align-items: center;
  flex-wrap: wrap;
  vertical-align: middle;
}

@media (max-width: 799px) {
  .active-discussions__more {
    width: 100%;
    max-width: none;
  }
}
.spanish-toast-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.active-discussions--queue :deep(.cdx-icon--flipped) { transform: scaleX(-1); }
</style>
