<script setup>
import { onMounted, onUnmounted, provide, ref } from 'vue'
import { CdxAccordion, CdxIcon } from '@wikimedia/codex'
import { cdxIconUserTalk, cdxIconCheck } from '@wikimedia/codex-icons'
import ChromeWrapper from '@/components/chrome/ChromeWrapper.vue'
import SpecialPageWrapper from '@/components/SpecialPageWrapper.vue'
import Dashboard from '@/components/dashboard/Dashboard.vue'
import DashboardModule from '@/components/dashboard/DashboardModule.vue'
import ActiveDiscussions from './ActiveDiscussions.vue'
import ReviewChanges from './ReviewChanges.vue'
import SpanishHeader from './SpanishHeader.vue'
const props = defineProps({ fullQueue: { type: Boolean, default: false } })
const translations = {
  'cdx-input-chip-aria-description': 'اضغط إدخال للتحرير أو حذف للإزالة',
  'cdx-dialog-close-button-label': 'إغلاق',
  'cdx-message-dismiss-button-label': 'إغلاق',
  'cdx-popover-close-button-label': 'إغلاق',
  'cdx-label-optional-flag': '(اختياري)',
  'cdx-search-input-search-button-label': 'بحث',
  'cdx-typeahead-search-search-results-label': 'نتائج البحث',
}
provide('CdxI18nFunction', (key) => translations[key])
const mobile = ref(innerWidth < 800),
  oldLang = document.documentElement.lang,
  oldDir = document.documentElement.dir,
  oldTitle = document.title
const resize = () => (mobile.value = innerWidth < 800)
onMounted(() => {
  document.documentElement.lang = 'ar'
  document.documentElement.dir = 'rtl'
  document.title = 'النقاشات النشطة — ويكيبيديا'
  addEventListener('resize', resize)
})
onUnmounted(() => {
  document.documentElement.lang = oldLang
  document.documentElement.dir = oldDir
  document.title = oldTitle
  removeEventListener('resize', resize)
})
const policies = [
  [
    'وجهة النظر المحايدة',
    'ينبغي أن تعرض المقالات وجهات النظر المنشورة في المصادر الموثوقة بتوازن.',
  ],
  [
    'إمكانية التحقق',
    'يجب أن تكون المعلومات قابلة للتحقق بالرجوع إلى مصادر منشورة.',
  ],
  ['المصادر الموثوقة', 'استخدم مصادر منشورة ومستقلة وموثوقة.'],
  ['افترض حسن النية', 'افترض أن الآخرين يسعون إلى تحسين ويكيبيديا.'],
]
</script>
<template>
  <ChromeWrapper
    v-if="!fullQueue"
    lang="ar"
    dir="rtl"
    :skin="mobile ? 'mobile' : 'desktop'"
    :last-edited-notice="false"
    :prototyping-settings="false"
  >
    <template #header><SpanishHeader /></template>
    <SpecialPageWrapper title="مرحبًا، مستخدم تجريبي!">
      <Dashboard class="spanish-dashboard">
        <template v-if="mobile" #mobile
          ><ActiveDiscussions /><ReviewChanges />
          <DashboardModule title="أثرك"
            ><div class="spanish-impact">
              <span><CdxIcon :icon="cdxIconUserTalk" /> <strong>3</strong> رسائل شكر مرسلة</span
              ><span><CdxIcon :icon="cdxIconCheck" /> <strong>62</strong> تعديلات مراجعة</span>
            </div></DashboardModule
          >
        </template>
        <template v-if="!mobile" #primary><ActiveDiscussions /><ReviewChanges /></template>
        <template v-if="!mobile" #sidebar
          ><DashboardModule title="أثرك"
            ><div class="spanish-impact">
              <span><CdxIcon :icon="cdxIconUserTalk" /> <strong>3</strong> رسائل شكر مرسلة</span
              ><span><CdxIcon :icon="cdxIconCheck" /> <strong>62</strong> تعديلات مراجعة</span>
            </div></DashboardModule
          ><DashboardModule title="السياسات والإرشادات"
            ><CdxAccordion v-for="[title, body] in policies" :key="title" separation="none"
              ><template #title>{{ title }}</template
              >{{ body }}</CdxAccordion
            ></DashboardModule
          ></template
        >
      </Dashboard>
    </SpecialPageWrapper>
    <template #footer
      ><footer class="spanish-footer" lang="ar">
        <p>نموذج لاختبار الاستخدام. لا تغيّر الإجراءات محتوى ويكيبيديا.</p>
        <nav aria-label="معلومات ويكيبيديا">
          <a
            href="https://foundation.wikimedia.org/wiki/Policy:Privacy_policy/ar"
            target="_blank"
            rel="noopener"
            >سياسة الخصوصية</a
          ><a
            href="https://ar.wikipedia.org/wiki/ويكيبيديا:حول"
            target="_blank"
            rel="noopener"
            >حول ويكيبيديا</a
          ><a
            href="https://ar.wikipedia.org/wiki/ويكيبيديا:إخلاء مسؤولية"
            target="_blank"
            rel="noopener"
            >إخلاء مسؤولية</a
          ><a
            href="https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/ar"
            target="_blank"
            rel="noopener"
            >شروط الاستخدام</a
          >
        </nav>
      </footer></template
    >
  </ChromeWrapper>
  <main dir="rtl" v-else class="spanish-full-queue" lang="ar" :data-skin="mobile ? 'mobile' : 'desktop'">
    <ActiveDiscussions full-queue />
  </main>
</template>
<style scoped>
.spanish-impact {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.spanish-impact > span {
  display: flex;
  align-items: center;
  gap: 8px;
}
.spanish-full-queue {
  max-width: 860px;
  margin: 0 auto;
  padding: 0 16px 24px;
}
.spanish-footer {
  padding: 24px;
  max-width: 1600px;
  margin: auto;
  border-top: 1px solid var(--border-color-subtle);
  color: var(--color-subtle);
  font-size: var(--font-size-small);
}
.spanish-footer p {
  margin: 0 0 8px;
}
.spanish-footer nav {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}
@media (min-width: 800px) {
  .spanish-dashboard :deep(.dashboard-main) {
    grid-template-columns: minmax(0, 1fr) minmax(0, 34%);
  }
}
@media (max-width: 799px) {
  .spanish-footer {
    padding: 24px 16px;
  }
}
</style>
