<script setup>
import DashboardPage from '../DashboardPage.vue'
definePage({ meta: { platform: 'web', hidden: true } })
</script>
<template><DashboardPage full-queue /></template>
