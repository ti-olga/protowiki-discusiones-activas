export const WIKI_ORIGIN = 'https://ar.wikipedia.org'
export const groups = [
 ['صفحات المجتمع', [
 ['المساعدة','أسئلة المساهمين الجدد حول التحرير واستخدام ويكيبيديا.'],
 ['الميدان','نقاشات المجتمع حول السياسات والتقنية واللغة والاقتراحات.'],
 ['نقاشات المجتمع','مقترحات وسياسات مفتوحة لمشاركة المجتمع.']]],
 ['صفحات النقاش', [
 ['المستخدمون','نقاشات بين مساهمي ويكيبيديا.'],
 ['المقالات','نقاشات حول تحسين المقالات.'],
 ['السياسات والإرشادات','نقاشات حول قواعد ويكيبيديا.'],
 ['مشاريع ويكي','تنسيق العمل في المواضيع المشتركة.'],
 ['صفحات أخرى','نقاشات القوالب والملفات والتصنيفات والوحدات.']]],
 ['المسائل الإدارية', [
 ['إخطار الإداريين','بلاغات ومشكلات تتطلب تدخلًا إداريًا.']]]
]
export const venues = {
 'المساعدة':['ويكيبيديا:فريق المساعدة/طلبات'],
 'الميدان':['ويكيبيديا:الميدان/سياسات','ويكيبيديا:الميدان/تقنية','ويكيبيديا:الميدان/اقتراحات','ويكيبيديا:الميدان/لغويات','ويكيبيديا:الميدان/منوعات','ويكيبيديا:الميدان/مشاريع شقيقة'],
 'نقاشات المجتمع':['ويكيبيديا:الميدان/سياسات','ويكيبيديا:الميدان/اقتراحات'],
 'السياسات والإرشادات':['ويكيبيديا:الميدان/سياسات'],
 'إخطار الإداريين':['ويكيبيديا:إخطار الإداريين','ويكيبيديا:ميدان الإداريين'],
}
export async function wikiAPI(params, signal) {
  const url = new URL('/w/api.php', WIKI_ORIGIN)
  url.search = new URLSearchParams({ format: 'json', formatversion: '2', origin: '*', ...params })
  let response
  for (let attempt = 0; attempt < 3; attempt++) {
    response = await fetch(url, { cache: 'no-store', signal: signal || AbortSignal.timeout(25000) })
    if (response.status !== 429 || attempt === 2) break
    const retry = Number(response.headers.get('Retry-After'))
    const delay = Number.isFinite(retry) && retry > 0 ? retry * 1000 : 1500 * (attempt + 1)
    if (delay > 15000) break
    await new Promise((resolve) => setTimeout(resolve, delay))
  }
  if (!response.ok) throw Error('استجابت ويكيبيديا بالحالة ' + response.status)
  const data = await response.json()
  if (data.error) throw Error(data.error.info)
  return data
}
export const wikiTextFromHTML = (html) =>
  new DOMParser()
    .parseFromString(html || '', 'text/html')
    .body.textContent.replace(/\s+/g, ' ')
    .trim()
export const isRecentDiscussion = (d) =>
  Number.isFinite(Number(d.latest)) &&
  d.latest > 0 &&
  Date.now() - d.latest >= 0 &&
  Date.now() - d.latest <= 30 * 86400000
export function discussionThreads(source, roots, type, interests = []) {
  const headings = []
  function find(items) {
    for (const item of items) {
      if (item.type === 'heading' && item.headingLevel === 2) headings.push(item)
      else if (item.type === 'heading') find(item.replies || [])
    }
  }
  find(roots)
  return headings
    .flatMap((thread) => {
      const comments = []
      function visit(item) {
        if (item.type === 'comment' && item.id && Number.isFinite(Date.parse(item.timestamp)))
          comments.push(item)
        for (const child of item.replies || []) visit(child)
      }
      visit(thread)
      if (!comments.length) return []
      comments.sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp))
      const title = wikiTextFromHTML(thread.html)
      if (!title) return []
      const body = comments.map((comment) => wikiTextFromHTML(comment.html)).join('\n\n')
      const topics =
        type === 'المقالات'
          ? interests
          : interests.filter((interest) =>
              (title + ' ' + body)
                .toLocaleLowerCase('ar')
                .includes(interest.toLocaleLowerCase('ar')),
            )
      if (interests.length && !topics.length) return []
      const base = WIKI_ORIGIN + '/wiki/' + encodeURIComponent(source.replace(/ /g, '_'))
      return [
        {
          title,
          topicTitle: title,
          source,
          pageTitle: source,
          type,
          types: [type],
          topics,
          comments: Number.isInteger(thread.commentCount) ? thread.commentCount : comments.length,
          people: Number.isInteger(thread.authorCount)
            ? thread.authorCount
            : new Set(comments.map((c) => c.author).filter(Boolean)).size,
          latest: Date.parse(comments[0].timestamp),
          latestTimestamp: comments[0].timestamp,
          topicId: thread.id,
          topicName: thread.name,
          url: base + '#' + encodeURIComponent(title.replace(/ /g, '_')),
          body: body.slice(0, 2500),
          live: true,
          structured: true,
        },
      ]
    })
    .filter(isRecentDiscussion)
    .sort((a, b) => b.latest - a.latest)
}
const relative = new Intl.RelativeTimeFormat('ar', { numeric: 'always', style: 'short' })
export function relativeWikiTime(timestamp) {
  const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000))
  return seconds < 60
    ? relative.format(-seconds, 'second')
    : seconds < 3600
      ? relative.format(-Math.floor(seconds / 60), 'minute')
      : seconds < 86400
        ? relative.format(-Math.floor(seconds / 3600), 'hour')
        : relative.format(-Math.floor(seconds / 86400), 'day')
}
const namespaces = { 'المستخدمون':'3', 'المقالات':'1', 'مشاريع ويكي':'5', 'صفحات أخرى':'7|11|13|15|829' }
export function createDiscussionLoader() {
  const cache = new Map(),
    queue = []
  let active = 0
  const drain = () => {
    while (active < 4 && queue.length) {
      const job = queue.shift()
      active++
      wikiAPI(job.params)
        .then(job.resolve, job.reject)
        .finally(() => {
          active--
          drain()
        })
    }
  }
  const api = (params) => {
    const key = JSON.stringify(params)
    if (!cache.has(key))
      cache.set(
        key,
        new Promise((resolve, reject) => {
          queue.push({ params, resolve, reject })
          drain()
        }),
      )
    return cache.get(key)
  }
  async function resolvePages(titles) {
    if (!titles.length) return []
    const data = await api({
      action: 'query',
      titles: titles.join('|'),
      redirects: 1,
      prop: 'info',
    })
    return (data.query?.pages || []).filter((p) => !p.missing).map((p) => p.title)
  }
  async function pagesForType(type, interests) {
    if (venues[type]) return resolvePages(venues[type])
    if (type === 'المقالات' && interests.length)
      return resolvePages(interests.map((title) => 'نقاش:' + title))
    if (namespaces[type]) {
      const changes = await api({
        action: 'query',
        list: 'recentchanges',
        rcnamespace: namespaces[type],
        rctype: 'edit|new',
        rcshow: '!bot',
        rcprop: 'title|timestamp',
        rclimit: '50',
      })
      return [...new Set((changes.query?.recentchanges || []).map((p) => p.title))]
        .filter((title) => !/أرشيف|archive/i.test(title))
        .filter((title) => type !== 'مشاريع ويكي' || /مشروع ويكي/.test(title))
        .slice(0, type === 'المقالات' ? 10 : 6)
    }
    return []
  }
  async function pageThreads(page, type, interests) {
    const json = await api({ action: 'discussiontoolspageinfo', page, prop: 'threaditemshtml' })
    return discussionThreads(
      page,
      json.discussiontoolspageinfo?.threaditemshtml || [],
      type,
      interests,
    )
  }
  async function loadType(type, interests) {
    const pages = await pagesForType(type, interests)
    const results = await Promise.allSettled(
      pages.map((page) => pageThreads(page, type, interests)),
    )
    let rows = results.flatMap((r) => (r.status === 'fulfilled' ? r.value : []))
    return { rows, failedPages: results.filter((r) => r.status === 'rejected').length, pages }
  }
  return { loadType, pageThreads, pagesForType }
}
export function mergeDiscussions(rows) {
  const merged = new Map()
  for (const row of rows) {
    const old = merged.get(row.url)
    merged.set(
      row.url,
      old
        ? {
            ...old,
            ...row,
            types: [...new Set([...old.types, ...row.types])],
            topics: [...new Set([...old.topics, ...row.topics])],
          }
        : row,
    )
  }
  return [...merged.values()]
}
