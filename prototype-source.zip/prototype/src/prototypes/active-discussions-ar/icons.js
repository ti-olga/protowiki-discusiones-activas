// Filled companion to Codex's cdxIconPushPin: identical outer path and 20×20
// viewBox, with only the inner cutout removed. Codex supplies the outline.
export const cdxIconPushPinFilled =
  '<path d="M16 2h-2v4.764l3 5.936V14h-6v6H9v-6H3v-1.3l3-5.936V2H4V0h12z"/>'

// Prototype-only filled variant of Codex's 20×20 funnel silhouette.
export const prototypeIconFunnelFilled =
  '<path d="M1 1h18v2.63l-6 7.71V19H7v-7.66L1 3.63z"/>'
