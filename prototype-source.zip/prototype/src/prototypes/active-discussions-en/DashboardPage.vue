<script setup>
import { onMounted, onUnmounted, ref } from 'vue'
import { CdxAccordion, CdxIcon } from '@wikimedia/codex'
import { cdxIconUserTalk, cdxIconCheck } from '@wikimedia/codex-icons'
import ChromeWrapper from '@/components/chrome/ChromeWrapper.vue'
import SpecialPageWrapper from '@/components/SpecialPageWrapper.vue'
import Dashboard from '@/components/dashboard/Dashboard.vue'
import DashboardModule from '@/components/dashboard/DashboardModule.vue'
import ActiveDiscussions from './ActiveDiscussions.vue'
import ReviewChanges from './ReviewChanges.vue'
import EnglishHeader from './EnglishHeader.vue'
const previousDocument = {lang:document.documentElement.lang,dir:document.documentElement.dir,title:document.title}
onMounted(()=>{document.documentElement.lang='en';document.documentElement.dir='ltr';document.title='Active discussions — Wikipedia'})
onUnmounted(()=>{document.documentElement.lang=previousDocument.lang;document.documentElement.dir=previousDocument.dir;document.title=previousDocument.title})
const props = defineProps({ fullQueue: { type: Boolean, default: false } })
const mobile = ref(window.innerWidth < 800)
function updateViewport() {
  mobile.value = window.innerWidth < 800
}
onMounted(() => window.addEventListener('resize', updateViewport))
onUnmounted(() => window.removeEventListener('resize', updateViewport))
const policies = [
  [
    'Neutral point of view',
    'Content must represent significant views fairly, proportionately and without bias.',
  ],
  [
    'No original research',
    'Content should summarise published sources, and not contain users’ own interpretation or knowledge.',
  ],
  [
    'Verifiability',
    'New additions should include a citation, providing the source of the information.',
  ],
  [
    'Assume good faith',
    'Remember that most users are trying to improve Wikipedia and not deliberately reduce its quality.',
  ],
]
</script>
<template>
  <ChromeWrapper
    v-if="!fullQueue"
    :skin="mobile ? 'mobile' : 'desktop'"
    lang="en"
    dir="ltr"
    :prototyping-settings="false"
    :last-edited-notice="false"
    username="$Username"
  >
    <template #header><EnglishHeader /></template>
    <SpecialPageWrapper v-if="!fullQueue" title="Hello, Test user!">
      <Dashboard class="active-discussions-dashboard">
        <template v-if="mobile" #mobile
          ><ActiveDiscussions /><ReviewChanges />
          <DashboardModule title="Your impact"
            ><div class="impact-values">
              <span
                ><CdxIcon :icon="cdxIconUserTalk" />
                <a
                  href="https://en.wikipedia.org/wiki/Special:Log/thanks"
                  target="_blank"
                  rel="noopener"
                  >3</a
                >
                Thanks sent</span
              ><span><CdxIcon :icon="cdxIconCheck" /> 62 Edits reviewed</span>
            </div></DashboardModule
          >
        </template>
        <template v-if="!mobile" #primary><ActiveDiscussions /><ReviewChanges /></template>
        <template v-if="!mobile" #sidebar>
          <DashboardModule title="Your impact"
            ><div class="impact-values">
              <span
                ><CdxIcon :icon="cdxIconUserTalk" />
                <a
                  href="https://en.wikipedia.org/wiki/Special:Log/thanks"
                  target="_blank"
                  rel="noopener"
                  >3</a
                >
                Thanks sent</span
              ><span><CdxIcon :icon="cdxIconCheck" /> 62 Edits reviewed</span>
            </div></DashboardModule
          >
          <DashboardModule title="Policies and guidelines"
            ><CdxAccordion v-for="[title, body] in policies" :key="title" separation="none"
              ><template #title>{{ title }}</template
              >{{ body }}</CdxAccordion
            ></DashboardModule
          >
        </template>
      </Dashboard>
    </SpecialPageWrapper>
  </ChromeWrapper>
  <div v-else lang="en" dir="ltr" class="active-discussions-full-queue" :data-skin="mobile ? 'mobile' : 'desktop'">
    <ActiveDiscussions full-queue />
  </div>
</template>
<style scoped>
.active-discussions-dashboard {
  --font-size-small: 14px;
}
.impact-values {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.impact-values > span {
  display: flex;
  align-items: center;
  gap: 8px;
}
.active-discussions-full-queue {
  max-width: 860px;
  margin: 0 auto;
  padding: 0 16px 24px;
}
@media (min-width: 800px) {
  .active-discussions-dashboard :deep(.dashboard-main) {
    grid-template-columns: minmax(0, 1fr) minmax(0, 34%);
  }
}
</style>
