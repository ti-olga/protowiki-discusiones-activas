<script setup>
import { ref } from 'vue'
import { CdxButton, CdxIcon, CdxMenuButton, CdxSearchInput } from '@wikimedia/codex'
import {
  cdxIconMenu,
  cdxIconSearch,
  cdxIconBell,
  cdxIconUserAvatar,
  cdxIconWatchlist,
  cdxIconAppearance,
  cdxIconTray,
  cdxIconBookmarkList,
  cdxIconDownTriangle,
  cdxIconClose,
} from '@wikimedia/codex-icons'
const baseUrl = import.meta.env.BASE_URL
const query = ref(''),
  searchOpen = ref(false)
const menu = [
  { value: 'Main Page', label: 'Main page' },
  { value: 'Wikipedia:Community portal', label: 'Community portal' },
  { value: 'Special:RecentChanges', label: 'Recent changes' },
  { value: 'Special:Random', label: 'Random article' },
  { value: 'Help:Contents', label: 'Help' },
]
const account = [
  { value: 'Special:MyPage', label: 'User page' },
  { value: 'Special:MyTalk', label: 'Talk' },
  { value: 'Special:Contributions', label: 'Contributions' },
  { value: 'Special:Preferences', label: 'Preferences' },
]
function wiki(page) {
  if (page)
    window.open(
      'https://en.wikipedia.org/wiki/' + encodeURIComponent(page.replace(/ /g, '_')),
      '_blank',
      'noopener',
    )
}
function search() {
  if (!query.value.trim()) return
  const url = new URL('https://en.wikipedia.org/w/index.php')
  url.search = new URLSearchParams({ title: 'Special:Search', search: query.value })
  window.open(url.href, '_blank', 'noopener')
}
</script>
<template>
  <header class="english-header">
    <nav class="english-header__bar" aria-label="Wikipedia navigation">
      <CdxMenuButton
        :selected="null"
        :menu-items="menu"
        aria-label="Main menu"
        weight="quiet"
        @update:selected="wiki"
        ><CdxIcon :icon="cdxIconMenu"
      /></CdxMenuButton>
      <a class="english-header__logo" :href="`${baseUrl}active-discussions-en`" aria-label="Go to homepage">
        <img
          class="english-header__globe"
          src="https://en.wikipedia.org/static/images/icons/wikipedia.png"
          alt=""
          width="50"
          height="50"
        />
        <span class="english-header__wordmark"
          ><img
            src="https://en.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-en-25.svg"
            alt="Wikipedia"
            width="120"
            height="18" /><img
            class="english-header__tagline"
            src="https://en.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-en.svg"
            alt="The Free Encyclopedia"
            width="120"
            height="13"
        /></span>
      </a>
      <form class="english-header__search" role="search" @submit.prevent="search">
        <CdxSearchInput
          v-model="query"
          aria-label="Search Wikipedia"
          placeholder="Search Wikipedia"
        /><CdxButton type="submit">Search</CdxButton>
      </form>
      <div class="english-header__tools">
        <CdxButton
          class="english-header__mobile-search"
          weight="quiet"
          :icon-only="true"
          aria-label="Search"
          @click="searchOpen = !searchOpen"
          ><CdxIcon :icon="cdxIconSearch"
        /></CdxButton>
        <a
          class="english-header__username"
          href="https://en.wikipedia.org/wiki/Special:MyPage"
          target="_blank"
          rel="noopener"
          >Test user</a
        >
        <CdxButton class="english-header__desktop-tool" weight="quiet" :icon-only="true" aria-label="Appearance" @click="wiki('Special:Preferences')"><CdxIcon :icon="cdxIconAppearance" /></CdxButton>
        <CdxButton
          weight="quiet"
          :icon-only="true"
          aria-label="Notifications"
          @click="wiki('Special:Notifications')"
          ><CdxIcon :icon="cdxIconBell"
        /></CdxButton>
        <CdxButton class="english-header__desktop-tool" weight="quiet" :icon-only="true" aria-label="Notices" @click="wiki('Special:Notifications')"><CdxIcon :icon="cdxIconTray" /></CdxButton>
        <CdxButton class="english-header__desktop-tool" weight="quiet" :icon-only="true" aria-label="Saved pages" @click="wiki('Special:Watchlist')"><CdxIcon :icon="cdxIconBookmarkList" /></CdxButton>
        <CdxButton
          class="english-header__watchlist"
          weight="quiet"
          :icon-only="true"
          aria-label="Watchlist"
          @click="wiki('Special:Watchlist')"
          ><CdxIcon :icon="cdxIconWatchlist"
        /></CdxButton>
        <CdxMenuButton
          :selected="null"
          :menu-items="account"
          aria-label="Personal tools"
          weight="quiet"
          @update:selected="wiki"
          ><CdxIcon :icon="cdxIconUserAvatar" /><CdxIcon class="english-header__caret" :icon="cdxIconDownTriangle" size="small" /></CdxMenuButton>
      </div>
    </nav>
    <form
      v-if="searchOpen"
      class="english-header__expanded-search"
      role="search"
      @submit.prevent="search"
    >
      <CdxSearchInput
        v-model="query"
        aria-label="Search Wikipedia"
        placeholder="Search Wikipedia"
      /><CdxButton type="submit">Search</CdxButton
      ><CdxButton
        weight="quiet"
        :icon-only="true"
        aria-label="Close search"
        @click="searchOpen = false"
        ><CdxIcon :icon="cdxIconClose"
      /></CdxButton>
    </form>
  </header>
</template>
<style scoped>
.english-header {
  background: var(--background-color-base);
  color: var(--color-base);
}
.english-header__bar {
  max-width: 1600px;
  margin: auto;
  min-height: 80px;
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 8px 24px;
  box-sizing: border-box;
}
.english-header__logo {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}
.english-header__wordmark {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.english-header__search {
  display: flex;
  align-items: center;
  flex: 1;
  max-width: 500px;
  margin: 0 24px;
}
.english-header__search > .cdx-search-input {
  flex: 1;
  min-width: 0;
}
.english-header__tools {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-left: auto;
}
.english-header__username {
  margin-right: 8px;
  white-space: nowrap;
}
.english-header__mobile-search {
  display: none;
}
.english-header__expanded-search {
  display: flex;
  padding: 8px 16px;
  gap: 8px;
}
@media (max-width: 1100px) {
  .english-header__search {
    display: none;
  }
  .english-header__mobile-search {
    display: inline-flex;
  }
  .english-header__globe {
    display: none;
  }
}
@media (max-width: 799px) {
  .english-header__bar {
    min-height: 56px;
    padding: 8px 16px;
    gap: 8px;
    background: var(--background-color-interactive-subtle);
  }
  .english-header__tagline,
  .english-header__username,
  .english-header__watchlist {
    display: none;
  }
  .english-header__tools {
    gap: 4px;
  }
  .english-header__wordmark img {
    width: 100px;
    height: 15px;
  }
}
/* Match the English dashboard chrome dimensions and tool order. */
@media (min-width: 800px) {
  .english-header__bar { max-width: none; min-height: 82px; padding: 8px 16px; gap: 16px; }
  .english-header__globe { display: none; }
  .english-header__logo { margin-left: 20px; }
  .english-header__wordmark { width: 152px; min-height: 44px; padding-block: 3px; gap: 2px; justify-content: space-between; }
  .english-header__wordmark img { width: auto; max-width: 100%; display: block; }
  .english-header__tools { gap: .2rem; }
  .english-header__username { font-size: 14px; margin-inline: 8px; }
  .english-header__tools :deep(.cdx-button) { height: 32px; min-width: 32px; padding: .5rem .4rem; }
  .english-header__search { max-width: 474px; margin: 0; padding-left: 24px; }
}
@media (min-width: 800px) and (max-width: 1120px) {
  .english-header__search { display: none; }
  .english-header__mobile-search { display: inline-flex; }
  .english-header__tools :deep(.cdx-button) { height: 40px; min-width: 40px; padding: .7rem; }
}
@media (max-width: 799px) {
 .english-header__desktop-tool, .english-header__caret { display: none; }
}
</style>
