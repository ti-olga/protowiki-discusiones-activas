<script setup>
import { computed, ref } from 'vue'
import {
  CdxCard,
  CdxButton,
  CdxInfoChip,
  CdxIcon,
  CdxMenuButton,
  CdxDialog,
  CdxToggleSwitch,
  CdxRadio,
} from '@wikimedia/codex'
import {
  cdxIconEllipsis,
  cdxIconConfigure,
  cdxIconInfo,
  cdxIconEye,
} from '@wikimedia/codex-icons'

const dialog = ref('')
const personalization = ref(localStorage.getItem('review-changes-en-testing-personalization') !== 'false')
let saved = {}
try {
  saved = JSON.parse(localStorage.getItem('review-en-testing-customize') || '{}')
} catch {}
const preferences = ref({
  version: 'Default',
  longSummaries: false,
  longTitles: false,
  longUsernames: false,
  ...saved,
})
const draft = ref({ ...preferences.value })
const items = [
  { value: 'personalization', label: 'Personalization', icon: cdxIconConfigure },
  {
    value: 'customize',
    label: 'Customize preview',
    icon: cdxIconEye,
  },
  { value: 'about', label: 'About Review changes', icon: cdxIconInfo },
]
const titles = {
  personalization: 'Personalization',
  customize: 'Customize preview',
  about: 'About Review changes',
}
const moreURL = computed(() => {
  const url = new URL(
    'https://olgati23.github.io/diff-page-navigation/pr-preview/pr-1/review-changes/',
  )
  url.searchParams.set('view', 'queue')
  url.searchParams.set('version', preferences.value.version)
  for (const key of ['longSummaries', 'longTitles', 'longUsernames'])
    if (preferences.value[key]) url.searchParams.set(key, '1')
  return url.href
})
function openReviewQueue() {
  window.open(moreURL.value, '_blank', 'noopener')
}
function setting(value) {
  draft.value = { ...preferences.value }
  dialog.value = value || ''
}
function save() {
  preferences.value = { ...draft.value }
  localStorage.setItem('review-en-testing-customize', JSON.stringify(preferences.value))
  dialog.value = ''
}
function personalize(value) {
  personalization.value = value
  localStorage.setItem('review-changes-en-testing-personalization', String(value))
}

const cards = [
  {
    title: 'Pandaren',
    description: 'Fictional race in the Warcraft franchise',
    summary: 'remove AI-generated article per WP:NOLLM',
    editor: 'Gnomingstuff',
    time: '8m ago',
    chip: { label: 'Major change', status: 'notice' },
  },
  {
    title: '2026 Braga Open – Singles',
    description: '2026 tennis event results',
    summary: '→Top half',
    editor: 'WildCherry06',
    time: '8m ago',
  },
  {
    title: 'V Battery Royal Horse Artillery',
    description: 'Former British Army airborne artillery battery',
    summary: 'Update to regimental history',
    editor: '~2026-53599-34',
    time: '8m ago',
    temporary: true,
    chip: { label: 'High revert risk', status: 'warning' },
  },
]
</script>
<template>
  <section class="review-changes">
    <div class="review-changes__header">
      <h2>Review changes</h2>
      <CdxMenuButton
        :selected="null"
        :menu-items="items"
        @update:selected="setting"
        aria-label="Review changes options"
        weight="quiet"
        ><CdxIcon :icon="cdxIconEllipsis"
      /></CdxMenuButton>
    </div>
    <div class="review-changes__cards">
      <CdxCard class="review-changes__card" v-for="card in cards" :key="card.title">
        <template #title>
          <span v-if="card.chip" class="review-changes__notice">
            <CdxInfoChip
              :status="card.chip.status"
              :icon="card.chip.status === 'notice' ? cdxIconInfo : undefined"
              >{{ card.chip.label }}</CdxInfoChip
            >
          </span>
          <span class="review-changes__title">{{ card.title }}</span>
        </template>
        <template #description>
          <span class="review-changes__description">{{ card.description }}</span>
          <p class="review-changes__summary">{{ card.summary }}</p>
        </template>
        <template #supporting-text>
          <div class="review-changes__meta">
            <span class="review-changes__editor">{{ card.editor }}</span>
            <span class="review-changes__time">{{ card.time }}</span>
          </div>
        </template>
      </CdxCard>
    </div>
    <CdxButton class="review-changes__more" @click="openReviewQueue">Show more</CdxButton>
    <CdxDialog
      :open="!!dialog"
      :title="titles[dialog] || 'Review changes'"
      :primary-action="
        dialog === 'customize' ? { label: 'Save', actionType: 'progressive' } : undefined
      "
      :default-action="{ label: dialog === 'customize' ? 'Cancel' : 'Close' }"
      @update:open="
        (value) => {
          if (!value) dialog = ''
        }
      "
      @default="dialog = ''"
      @primary="save"
    >
      <CdxToggleSwitch
        v-if="dialog === 'personalization'"
        :model-value="personalization"
        @update:model-value="personalize"
        >Personalization<template #description
          >Suggest changes from your Watchlist, pages you have edited, and related pages.</template
        ></CdxToggleSwitch
      >
      <template v-else-if="dialog === 'customize'"
        ><fieldset class="review-field">
          <legend>Version</legend>
          <CdxRadio
            v-for="version in ['Default', 'Older']"
            :key="version"
            v-model="draft.version"
            name="review-version"
            :input-value="version"
            >{{ version }}</CdxRadio
          >
        </fieldset>
        <fieldset class="review-field">
          <legend>Edits to show</legend>
          <CdxToggleSwitch
            v-for="[key, label, description] in [
              ['longSummaries', 'Long edit summaries', '120 characters or more'],
              ['longTitles', 'Long titles', '40 characters or more'],
              ['longUsernames', 'Long usernames', '20 characters or more'],
            ]"
            :key="key"
            v-model="draft[key]"
            >{{ label }}<template #description>{{ description }}</template></CdxToggleSwitch
          >
        </fieldset></template
      >
      <p v-else>
        These edits were made by other users. Stay up to date and help maintain Wikipedia’s quality
        by reviewing them.
      </p>
    </CdxDialog>
  </section>
</template>
<style scoped>
.review-changes {
  margin-top: 24px;
}
.review-changes__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
}
.review-changes__header h2 {
  margin: 0;
  font: var(--font-weight-bold) var(--font-size-x-large)/var(--line-height-x-large)
    var(--font-family-system-sans);
}
.review-changes__cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.review-changes__more {
  display: inline-block;
  margin-top: 12px;
  font-weight: var(--font-weight-bold);
}
@media (max-width: 799px) {
  .review-changes__header h2 {
    font-size: var(--font-size-large);
  }
}
.review-field {
  border: 0;
  margin: 0 0 24px;
  padding: 0;
}
.review-field legend {
  font-weight: var(--font-weight-bold);
  margin-bottom: 12px;
}
.review-changes__card {
  display: block;
  padding: 12px;
}

.review-changes__title {
  color: var(--color-base);
  font: var(--font-weight-bold) var(--font-size-medium)/var(--line-height-small)
    var(--font-family-system-sans);
}
.review-changes__description {
  color: var(--color-subtle);
  font: var(--font-weight-normal) var(--font-size-medium)/var(--line-height-small)
    var(--font-family-system-sans);
}
.review-changes__summary {
  margin: 6px 0 4px;
  color: var(--color-base);
  font: italic var(--font-weight-normal) var(--font-size-medium)/var(--line-height-small)
    var(--font-family-system-sans);
}
.review-changes__meta {
  display: flex;
  justify-content: space-between;
  align-items: baseline;
  width: 100%;
  gap: 12px;
  color: var(--color-subtle);
  font: var(--font-weight-normal) var(--font-size-small)/var(--line-height-small)
    var(--font-family-system-sans);
}
.review-changes__editor {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  min-width: 0;
  overflow-wrap: anywhere;
}
.review-changes__time {
  margin-left: auto;
  white-space: nowrap;
}

.review-changes__notice {
  display: block;
  margin-bottom: 12px;
  font-weight: var(--font-weight-normal);
}
.review-changes__more {
  box-sizing: border-box;
}

@media(max-width:799px){.review-changes__more{display:flex;width:100%;max-width:none;justify-content:center;}}
</style>
