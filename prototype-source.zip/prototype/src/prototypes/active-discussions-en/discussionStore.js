import { computed, reactive, watch, ref } from 'vue'
import {
  groups,
  wikiAPI,
  discussionThreads,
  pagesForType,
  loadCentralizedDiscussions,
  isRecentDiscussion,
} from './discussionData.js'

export const clock = ref(Date.now())
const clockTimer = setInterval(() => {
  clock.value = Date.now()
}, 15000)
if (import.meta.hot) import.meta.hot.dispose(() => clearInterval(clockTimer))
const STORAGE_KEY = 'protowiki-active-discussions-en-testing-v1'
function readSaved() {
  try {
    const current=localStorage.getItem(STORAGE_KEY)
    return current ? JSON.parse(current) : {}
  } catch {
    return {}
  }
}
const saved = readSaved()
const emptyVersion = () => ({ pins: [], subscriptions: [], view: 'all', collapsed: false })
export const state = reactive({
  version: 'B',
  types: saved.types || [],
  interests: saved.interests || [],
  versions: Object.fromEntries(
    ['B'].map((v) => [v, { ...emptyVersion(), ...saved.versions?.[v] }]),
  ),
  opened: saved.opened || {},
  preferences: saved.preferences || {},
  records: (saved.records || []).filter(isRecentDiscussion),
  liveUrls: saved.liveUrls || [],
  busy: false,
  error: '',
  limit: 3,
  expanded: false,
})
const persisted = () => ({
  version: state.version,
  types: state.types,
  interests: state.interests,
  versions: state.versions,
  opened: state.opened,
  preferences: state.preferences,
  records: state.records,
  liveUrls: state.liveUrls,
})
watch(
  persisted,
  (value) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(value))
    } catch {
      try {
        const ids = new Set(
          Object.values(state.versions).flatMap((v) => [...v.pins, ...v.subscriptions]),
        )
        localStorage.setItem(
          STORAGE_KEY,
          JSON.stringify({ ...value, records: value.records.filter((d) => ids.has(d.url)) }),
        )
      } catch {
        state.error = 'Your browser could not save these changes. Check available storage.'
      }
    }
  },
  { deep: true },
)
export const current = computed(() => state.versions[state.version])
// Session-only rows retained after using a Version B card's quick action.
// Saved membership changes immediately; the outline remains for three seconds.
export const pendingRemoval = reactive({ pins: [], subscriptions: [] })
export const recent = computed(() => state.records.filter(isRecentDiscussion))
export const pinned = computed(() =>
  recent.value
    .filter((d) => current.value.pins.includes(d.url))
    .sort((a, b) => b.latest - a.latest),
)
export const subscribed = computed(() =>
  recent.value
    .filter((d) => current.value.subscriptions.includes(d.url))
    .sort((a, b) => b.latest - a.latest),
)
export const ordered = computed(() => {
  const matching = recent.value.filter(
    (d) =>
      state.liveUrls.includes(d.url) &&
      (!state.types.length || state.types.includes(d.type)) &&
      (!state.interests.length || d.topics.some((t) => state.interests.includes(t))),
  )
  matching.sort(
    (a, b) =>
      (state.preferences[b.url] || 0) - (state.preferences[a.url] || 0) || b.latest - a.latest,
  )
  const featured = matching
    .filter((d) => d.type === 'Centralized discussion')
    .sort((a, b) => b.comments - a.comments || b.latest - a.latest)[0]
  const all = featured ? [featured, ...matching.filter((d) => d.url !== featured.url)] : matching
  if (current.value.view === 'pinned')
    return state.version === 'B'
      ? recent.value.filter(d => current.value.pins.includes(d.url) || pendingRemoval.pins.includes(d.url)).sort((a,b) => b.latest-a.latest)
      : pinned.value
  if (current.value.view === 'subscribed')
    return state.version === 'D'
      ? [
          ...pinned.value.filter((d) => current.value.subscriptions.includes(d.url)),
          ...subscribed.value.filter((d) => !current.value.pins.includes(d.url)),
        ]
      : state.version === 'B'
        ? recent.value.filter(d => current.value.subscriptions.includes(d.url) || pendingRemoval.subscriptions.includes(d.url)).sort((a,b) => b.latest-a.latest)
        : subscribed.value
  if (state.version === 'A' || state.version === 'D')
    return [...pinned.value, ...all.filter((d) => !current.value.pins.includes(d.url))]
  return all
})
export const readKey = (d) => d.source + '|' + (d.topicName || d.topicId || d.title)
export const isOpened = (d) => !!state.opened[readKey(d)]
export const hasNew = (d) => {
  const opened = state.opened[readKey(d)]
  return !!opened && d.latest > Math.max(opened.openedAt || 0, opened.latest || 0)
}
export function markOpened(d) {
  state.opened[readKey(d)] = { openedAt: Date.now(), latest: d.latest }
}
export function resetLimit() {
  state.limit = 3
  state.expanded = false
}
const quickRemovalTimers = new Map()
if (import.meta.hot) import.meta.hot.dispose(() => {
  for (const timer of quickRemovalTimers.values()) clearTimeout(timer)
})
export function toggleSaved(kind, d, deferRemoval = false) {
  const ids = current.value[kind]
  const index = ids.indexOf(d.url)
  if (state.version === 'B') {
    const timerKey = kind + ':' + d.url
    clearTimeout(quickRemovalTimers.get(timerKey))
    quickRemovalTimers.delete(timerKey)
    const retained = pendingRemoval[kind]
    const previous = retained.indexOf(d.url)
    if (previous >= 0) retained.splice(previous, 1)
    if (index >= 0 && deferRemoval) {
      retained.push(d.url)
      const timer = setTimeout(() => {
        const position = pendingRemoval[kind].indexOf(d.url)
        if (position >= 0) pendingRemoval[kind].splice(position, 1)
        quickRemovalTimers.delete(timerKey)
      }, 3000)
      timer.unref?.()
      quickRemovalTimers.set(timerKey, timer)
    }
  }
  if (index < 0) ids.push(d.url)
  else ids.splice(index, 1)
  return index < 0
}
let generation = 0,
  started = false
export async function loadDiscussions() {
  started = true
  const request = ++generation
  state.busy = true
  state.error = ''
  resetLimit()
  const selected = state.types.length
    ? [...state.types]
    : groups.flatMap(([, items]) => items.map(([type]) => type))
  const interests = [...state.interests]
  let failures = 0
  const batches = await Promise.allSettled(
    selected.map(async (type) => {
      if (type === 'Centralized discussion') return loadCentralizedDiscussions(interests)
      const pages = await pagesForType(type, interests)
      const results = await Promise.allSettled(
        pages.map(async (page) => {
          const json = await wikiAPI({
            action: 'discussiontoolspageinfo',
            page,
            prop: 'threaditemshtml',
          })
          return discussionThreads(
            page,
            json.discussiontoolspageinfo?.threaditemshtml || [],
            type,
            interests,
          )
        }),
      )
      failures += results.filter((r) => r.status === 'rejected').length
      return results.flatMap((r) => (r.status === 'fulfilled' ? r.value : []))
    }),
  )
  if (request !== generation) return
  failures += batches.filter((r) => r.status === 'rejected').length
  const savedIds = new Set(
    Object.values(state.versions).flatMap((v) => [...v.pins, ...v.subscriptions]),
  )
  const savedSources = [
    ...new Set(state.records.filter((d) => savedIds.has(d.url)).map((d) => d.source)),
  ]
  const savedUpdates = await Promise.allSettled(
    savedSources.map(async (source) => {
      const json = await wikiAPI({
        action: 'discussiontoolspageinfo',
        page: source,
        prop: 'threaditemshtml',
      })
      return discussionThreads(
        source,
        json.discussiontoolspageinfo?.threaditemshtml || [],
        state.records.find((d) => d.source === source).type,
        [],
        true,
      ).filter((d) => savedIds.has(d.url))
    }),
  )
  if (request !== generation) return
  const found = [
    ...new Map(
      batches
        .flatMap((r) => (r.status === 'fulfilled' ? r.value : []))
        .sort(
          (a, b) =>
            Number(a.type === 'Centralized discussion') -
            Number(b.type === 'Centralized discussion'),
        )
        .map((d) => [d.url, d]),
    ).values(),
  ]
  const records = new Map(state.records.map((d) => [d.url, d]))
  for (const result of savedUpdates)
    if (result.status === 'fulfilled') for (const d of result.value) records.set(d.url, d)
  for (const d of found) records.set(d.url, d)
  state.records = [...records.values()].filter(isRecentDiscussion)
  state.liveUrls = found.map((d) => d.url)
  state.busy = false
  if (failures) state.error = 'Some discussions could not be loaded. Try again.'
}
export function ensureLoaded() {
  if (!started) loadDiscussions()
}
