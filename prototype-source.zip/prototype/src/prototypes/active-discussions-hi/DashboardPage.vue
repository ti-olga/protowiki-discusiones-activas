<script setup>
import { onMounted, onUnmounted, provide, ref } from 'vue'
import { CdxAccordion, CdxIcon } from '@wikimedia/codex'
import { cdxIconUserTalk, cdxIconCheck } from '@wikimedia/codex-icons'
import ChromeWrapper from '@/components/chrome/ChromeWrapper.vue'
import SpecialPageWrapper from '@/components/SpecialPageWrapper.vue'
import Dashboard from '@/components/dashboard/Dashboard.vue'
import DashboardModule from '@/components/dashboard/DashboardModule.vue'
import ActiveDiscussions from './ActiveDiscussions.vue'
import ReviewChanges from './ReviewChanges.vue'
import SpanishHeader from './SpanishHeader.vue'
const props = defineProps({ fullQueue: { type: Boolean, default: false } })
const translations = {
  'cdx-input-chip-aria-description': 'संपादन के लिए Enter या हटाने के लिए Delete दबाएँ',
  'cdx-dialog-close-button-label': 'बंद करें',
  'cdx-message-dismiss-button-label': 'बंद करें',
  'cdx-popover-close-button-label': 'बंद करें',
  'cdx-label-optional-flag': '(वैकल्पिक)',
  'cdx-search-input-search-button-label': 'खोजें',
  'cdx-typeahead-search-search-results-label': 'खोज परिणाम',
}
provide('CdxI18nFunction', (key) => translations[key])
const mobile = ref(innerWidth < 800),
  oldLang = document.documentElement.lang,
  oldDir = document.documentElement.dir,
  oldTitle = document.title
const resize = () => (mobile.value = innerWidth < 800)
onMounted(() => {
  document.documentElement.lang = 'hi'
  document.documentElement.dir = 'ltr'
  document.title = 'सक्रिय चर्चाएँ — विकिपीडिया'
  addEventListener('resize', resize)
})
onUnmounted(() => {
  document.documentElement.lang = oldLang
  document.documentElement.dir = oldDir
  document.title = oldTitle
  removeEventListener('resize', resize)
})
const policies = [
  [
    'तटस्थ दृष्टिकोण',
    'लेखों में विश्वसनीय स्रोतों में प्रकाशित दृष्टिकोणों को संतुलित रूप से प्रस्तुत करना चाहिए।',
  ],
  [
    'सत्यापनीयता',
    'जानकारी की पुष्टि प्रकाशित स्रोतों के संदर्भों से होनी चाहिए।',
  ],
  ['विश्वसनीय स्रोत', 'प्रकाशित, स्वतंत्र और विश्वसनीय स्रोतों का इस्तेमाल करें।'],
  ['अच्छी नीयत मानें', 'मानें कि दूसरे लोग विकिपीडिया को बेहतर बनाना चाहते हैं।'],
]
</script>
<template>
  <ChromeWrapper
    v-if="!fullQueue"
    lang="hi"
    dir="ltr"
    :skin="mobile ? 'mobile' : 'desktop'"
    :last-edited-notice="false"
    :prototyping-settings="false"
  >
    <template #header><SpanishHeader /></template>
    <SpecialPageWrapper title="नमस्ते, परीक्षण सदस्य!">
      <Dashboard class="spanish-dashboard">
        <template v-if="mobile" #mobile
          ><ActiveDiscussions /><ReviewChanges />
          <DashboardModule title="आपका प्रभाव"
            ><div class="spanish-impact">
              <span><CdxIcon :icon="cdxIconUserTalk" /> <strong>3</strong> धन्यवाद भेजे गए</span
              ><span><CdxIcon :icon="cdxIconCheck" /> <strong>62</strong> संपादनों की समीक्षा की गई</span>
            </div></DashboardModule
          >
        </template>
        <template v-if="!mobile" #primary><ActiveDiscussions /><ReviewChanges /></template>
        <template v-if="!mobile" #sidebar
          ><DashboardModule title="आपका प्रभाव"
            ><div class="spanish-impact">
              <span><CdxIcon :icon="cdxIconUserTalk" /> <strong>3</strong> धन्यवाद भेजे गए</span
              ><span><CdxIcon :icon="cdxIconCheck" /> <strong>62</strong> संपादनों की समीक्षा की गई</span>
            </div></DashboardModule
          ><DashboardModule title="नीतियाँ और दिशानिर्देश"
            ><CdxAccordion v-for="[title, body] in policies" :key="title" separation="none"
              ><template #title>{{ title }}</template
              >{{ body }}</CdxAccordion
            ></DashboardModule
          ></template
        >
      </Dashboard>
    </SpecialPageWrapper>
    <template #footer
      ><footer class="spanish-footer" lang="hi">
        <p>उपयोगिता परीक्षण का प्रोटोटाइप। यहाँ की गई कार्रवाइयों से विकिपीडिया नहीं बदलता।</p>
        <nav aria-label="विकिपीडिया की जानकारी">
          <a
            href="https://foundation.wikimedia.org/wiki/Policy:Privacy_policy/hi"
            target="_blank"
            rel="noopener"
            >गोपनीयता नीति</a
          ><a
            href="https://hi.wikipedia.org/wiki/विकिपीडिया:परिचय"
            target="_blank"
            rel="noopener"
            >विकिपीडिया के बारे में</a
          ><a
            href="https://hi.wikipedia.org/wiki/विकिपीडिया:अस्वीकरण"
            target="_blank"
            rel="noopener"
            >अस्वीकरण</a
          ><a
            href="https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/hi"
            target="_blank"
            rel="noopener"
            >उपयोग की शर्तें</a
          >
        </nav>
      </footer></template
    >
  </ChromeWrapper>
  <main v-else class="spanish-full-queue" lang="hi" :data-skin="mobile ? 'mobile' : 'desktop'">
    <ActiveDiscussions full-queue />
  </main>
</template>
<style scoped>
.spanish-impact {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.spanish-impact > span {
  display: flex;
  align-items: center;
  gap: 8px;
}
.spanish-full-queue {
  max-width: 860px;
  margin: 0 auto;
  padding: 0 16px 24px;
}
.spanish-footer {
  padding: 24px;
  max-width: 1600px;
  margin: auto;
  border-top: 1px solid var(--border-color-subtle);
  color: var(--color-subtle);
  font-size: var(--font-size-small);
}
.spanish-footer p {
  margin: 0 0 8px;
}
.spanish-footer nav {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}
@media (min-width: 800px) {
  .spanish-dashboard :deep(.dashboard-main) {
    grid-template-columns: minmax(0, 1fr) minmax(0, 34%);
  }
}
@media (max-width: 799px) {
  .spanish-footer {
    padding: 24px 16px;
  }
}
</style>
