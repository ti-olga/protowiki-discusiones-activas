<script setup>
import { cdxIconPushPinFilled } from './icons'
import { computed } from 'vue'
import { CdxButton, CdxCard, CdxIcon, CdxInfoChip, CdxMenuButton } from '@wikimedia/codex'
import {
  cdxIconPushPin,
  cdxIconBell,
  cdxIconBellOutline,
  cdxIconEllipsis,
  cdxIconInfo,
  cdxIconSpeechBubble,
  cdxIconUserAvatarOutline,
  cdxIconAdd,
  cdxIconSubtract,
} from '@wikimedia/codex-icons'
import { state, current, pendingRemoval, clock, hasNew, isOpened, markOpened } from './discussionStore'
import { relativeWikiTime } from './discussionData'
const props = defineProps({ discussion: { type: Object, required: true } })
const emit = defineEmits(['pin', 'subscribe', 'prefer', 'less'])
const pinned = computed(() => current.value.pins.includes(props.discussion.url))
const subscribed = computed(() => current.value.subscriptions.includes(props.discussion.url))
const chip = computed(() =>
  hasNew(props.discussion)
    ? 'नई टिप्पणियाँ'
    : props.discussion.types?.includes('सामुदायिक चर्चाएँ')
      ? 'आपकी राय चाहिए'
      : null,
)
const read = computed(() => isOpened(props.discussion))
const items = computed(() => [
  {
    value: 'pin',
    label: pinned.value ? 'पिन हटाएँ' : 'पिन करें',
    icon: pinned.value ? cdxIconPushPinFilled : cdxIconPushPin,
  },
  {
    value: 'subscribe',
    label: subscribed.value ? 'सदस्यता समाप्त करें' : 'सदस्यता लें',
    icon: subscribed.value ? cdxIconBell : cdxIconBellOutline,
  },
  { value: 'prefer', label: 'इस प्रकार की और चर्चाएँ दिखाएँ', icon: cdxIconAdd },
  { value: 'less', label: 'इस प्रकार की कम चर्चाएँ दिखाएँ', icon: cdxIconSubtract },
])
const url = computed(() => {
  const url = new URL(props.discussion.url)
  url.searchParams.set('useskin', 'vector-2022')
  return url.href
})
function action(value) {
  if (value) emit(value, props.discussion)
}
function openCard(event) {
  if (event.target.closest('a,button,.cdx-menu-button,.cdx-menu')) return
  window.open(url.value, '_blank', 'noopener')
  markOpened(props.discussion)
}
</script>
<template>
  <CdxCard role="article" class="discussion-card" :class="{ 'discussion-card--opened': read }" @click="openCard">
    <template #supporting-text><div class="discussion-card__content">
    <div class="discussion-card__top">
      <div class="discussion-card__lead">
        <CdxInfoChip
          v-if="chip"
          :status="chip === 'नई टिप्पणियाँ' || read ? 'subtle' : 'notice'"
          :icon="chip === 'नई टिप्पणियाँ' ? undefined : cdxIconInfo"
          class="discussion-card__chip"
          >{{ chip }}</CdxInfoChip
        >
        <h3 v-else class="discussion-card__title">
          <a :href="url" target="_blank" rel="noopener" @click="markOpened(discussion)">{{
            discussion.title
          }}</a>
        </h3>
      </div>
      <div class="discussion-card__actions" @click.stop>
        <CdxButton
          v-if="pinned || pendingRemoval.pins.includes(discussion.url)"
          weight="quiet"
          :icon-only="true"
          :aria-label="pinned ? 'चर्चा का पिन हटाएँ' : 'चर्चा पिन करें'"
          @click="emit('pin', discussion, true)"
          ><CdxIcon :icon="pinned ? cdxIconPushPinFilled : cdxIconPushPin"
        /></CdxButton>
        <CdxButton
          v-if="subscribed || pendingRemoval.subscriptions.includes(discussion.url)"
          weight="quiet"
          :icon-only="true"
          :aria-label="subscribed ? 'सदस्यता समाप्त करें' : 'चर्चा की सदस्यता लें'"
          @click="emit('subscribe', discussion, true)"
          ><CdxIcon :icon="subscribed ? cdxIconBell : cdxIconBellOutline"
        /></CdxButton>
        <CdxMenuButton
          :selected="null"
          :menu-items="items"
          :menu-config="{ placement: 'bottom-end' }"
          weight="quiet"
          :aria-label="'चर्चा के विकल्प: ' + discussion.title"
          @update:selected="action"
          ><CdxIcon :icon="cdxIconEllipsis"
        /></CdxMenuButton>
      </div>
    </div>
    <h3 v-if="chip" class="discussion-card__title discussion-card__title--after-chip">
      <a :href="url" target="_blank" rel="noopener" @click="markOpened(discussion)">{{
        discussion.title
      }}</a>
    </h3>
    <p class="discussion-card__source">{{ discussion.pageTitle || discussion.source }}</p>
    <div class="discussion-card__meta">
      <span
        :aria-label="
          discussion.comments + (discussion.comments === 1 ? ' टिप्पणी' : ' टिप्पणियाँ')
        "
        ><CdxIcon :icon="cdxIconSpeechBubble" /> {{ discussion.comments }}</span
      >
      <span
        :aria-label="
          discussion.people + (discussion.people === 1 ? ' प्रतिभागी' : ' प्रतिभागी')
        "
        ><CdxIcon :icon="cdxIconUserAvatarOutline" /> {{ discussion.people }}</span
      >
      <time
        :datetime="discussion.latestTimestamp"
        :title="new Date(discussion.latest).toLocaleString('hi')"
        >{{ relativeWikiTime(discussion.latest, clock) }}</time
      >
    </div>
    </div></template>
  </CdxCard>
</template>
<style scoped>
.discussion-card :deep(.cdx-card__text) { min-width: 0; width: 100%; }
.discussion-card__content { color: var(--color-base); }
.discussion-card {
  border: 1px solid var(--border-color-subtle);
  padding: 12px;
  background: var(--background-color-base);
  color: var(--color-base);
  cursor: pointer;
  min-width: 0;
}
.discussion-card__top {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: 12px;
}
.discussion-card__lead {
  min-width: 0;
  flex: 1;
}
.discussion-card__actions {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  margin-top: -6px;
  margin-bottom: -6px;
}
.discussion-card__title {
  margin: 0;
  padding: 0;
  font: var(--font-weight-bold) var(--font-size-medium)/var(--line-height-small)
    var(--font-family-system-sans);
  overflow-wrap: anywhere;
}
.discussion-card__title a {
  color: inherit;
  text-decoration: none;
}
.discussion-card__title a:hover {
  text-decoration: underline;
}
.discussion-card__title--after-chip {
  margin-top: 8px;
}
.discussion-card__source {
  margin: 4px 0 12px;
  color: var(--color-subtle);
  font: var(--font-weight-normal) var(--font-size-medium)/var(--line-height-small)
    var(--font-family-system-sans);
  overflow-wrap: anywhere;
}
.discussion-card__meta {
  display: flex;
  align-items: center;
  gap: 12px;
  font-size: var(--font-size-small);
  color: var(--color-subtle);
}
.discussion-card__meta > span {
  display: inline-flex;
  align-items: center;
  gap: 4px;
}
.discussion-card__meta time {
  margin-left: auto;
  white-space: nowrap;
}
.discussion-card__chip {
  --font-size-small: 12px;
  --line-height-small: 18px;
}
.discussion-card--opened .discussion-card__content,
.discussion-card--opened {
  color: var(--color-subtle);
}
.discussion-card--opened .discussion-card__title {
  font-weight: var(--font-weight-normal);
}
</style>
