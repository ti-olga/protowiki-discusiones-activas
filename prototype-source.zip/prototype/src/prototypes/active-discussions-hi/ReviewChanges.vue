<script setup>
import { computed, onMounted, ref } from 'vue'
import {
  CdxCard,
  CdxInfoChip,
  CdxButton,
  CdxIcon,
  CdxMenuButton,
  CdxDialog,
  CdxProgressBar,
  CdxMessage,
} from '@wikimedia/codex'
import { cdxIconEllipsis, cdxIconInfo } from '@wikimedia/codex-icons'
import { wikiAPI, relativeWikiTime, wikiTextFromHTML } from './discussionData'
import { clock } from './discussionStore'
const changes = ref([]),
  busy = ref(true),
  error = ref(false),
  about = ref(false)
async function load() {
  busy.value = true
  error.value = false
  try {
    const json = await wikiAPI({
      action: 'query',
      list: 'recentchanges',
      rcnamespace: '0',
      rctype: 'edit',
      rcshow: '!bot|!minor',
      rcprop: 'title|user|comment|parsedcomment|timestamp|sizes',
      rclimit: '3',
    })
    const rows = json.query?.recentchanges || []
    const descriptions = rows.length
      ? await wikiAPI({
          action: 'query',
          prop: 'description',
          titles: rows.map((r) => r.title).join('|'),
        })
      : {}
    const pages = descriptions.query?.pages || []
    changes.value = rows.map((row) => ({
      ...row,
      summary: wikiTextFromHTML(row.parsedcomment || row.comment || ''),
      description: pages.find((p) => p.title === row.title)?.description || '',
      major: Math.abs((row.newlen || 0) - (row.oldlen || 0)) >= 500,
    }))
  } catch {
    error.value = true
  } finally {
    busy.value = false
  }
}
onMounted(load)
function more() {
  window.open('https://hi.wikipedia.org/wiki/Special:RecentChanges', '_blank', 'noopener')
}
</script>
<template>
  <section class="spanish-review">
    <div class="spanish-review__header">
      <h2>बदलावों की समीक्षा करें</h2>
      <CdxMenuButton
        :selected="null"
        :menu-items="[{ value: 'about', label: 'बदलावों की समीक्षा के बारे में', icon: cdxIconInfo }]"
        aria-label="बदलावों की समीक्षा के विकल्प"
        @update:selected="about = true"
        ><CdxIcon :icon="cdxIconEllipsis"
      /></CdxMenuButton>
    </div>
    <CdxProgressBar v-if="busy" inline aria-label="हाल में हुए परिवर्तन लोड हो रहे हैं" />
    <CdxMessage v-else-if="error" type="notice"
      >हाल में हुए परिवर्तन लोड नहीं हो सके।
      <CdxButton weight="quiet" @click="load">फिर से कोशिश करें</CdxButton></CdxMessage
    >
    <div v-else class="spanish-review__cards">
      <CdxCard v-for="card in changes" :key="card.rcid" class="spanish-review__card"
        ><template #title
          ><span v-if="card.major" class="spanish-review__notice"
            ><CdxInfoChip status="notice" :icon="cdxIconInfo">बड़ा बदलाव</CdxInfoChip></span
          ><span class="spanish-review__title">{{ card.title }}</span></template
        ><template #description
          ><span>{{ card.description }}</span>
          <p v-if="card.summary" class="spanish-review__summary">{{ card.summary }}</p></template
        ><template #supporting-text
          ><div class="spanish-review__meta">
            <span>{{ card.user }}</span
            ><time :datetime="card.timestamp">{{
              relativeWikiTime(Date.parse(card.timestamp), clock)
            }}</time>
          </div></template
        ></CdxCard
      >
    </div>
    <CdxButton class="spanish-review__more" @click="more">और दिखाएँ</CdxButton>
    <CdxDialog
      use-close-button
      v-model:open="about"
      title="बदलावों की समीक्षा के बारे में"
      close-button-label="बंद करें"
      :default-action="{ label: 'बंद करें' }"
      @default="about = false"
      ><p>
        ये संपादन दूसरे योगदानकर्ताओं ने किए हैं। हाल के बदलावों की समीक्षा करके विकिपीडिया की गुणवत्ता बनाए रखने में मदद करें।
      </p></CdxDialog
    >
  </section>
</template>
<style scoped>
.spanish-review {
  margin-top: 24px;
  min-width: 0;
}
.spanish-review__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: 12px;
  gap: 12px;
}
.spanish-review__header h2 {
  margin: 0;
  font: var(--font-weight-bold) var(--font-size-x-large)/var(--line-height-x-large)
    var(--font-family-system-sans);
}
.spanish-review__cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
}
.spanish-review__card {
  display: block;
  padding: 12px;
}
.spanish-review__notice {
  display: block;
  margin-bottom: 12px;
  font-weight: var(--font-weight-normal);
}
.spanish-review__title {
  font-size: var(--font-size-medium);
}
.spanish-review__summary {
  margin: 6px 0 4px;
  color: var(--color-base);
  font-style: italic;
  overflow-wrap: anywhere;
}
.spanish-review__meta {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: 12px;
  width: 100%;
  color: var(--color-subtle);
  font-size: var(--font-size-small);
}
.spanish-review__meta > span {
  min-width: 0;
  overflow-wrap: anywhere;
}
.spanish-review__meta time {
  margin-left: auto;
  white-space: nowrap;
}
.spanish-review__more {
  margin-top: 12px;
}
@media (max-width: 799px) {
  .spanish-review__header h2 {
    font-size: var(--font-size-large);
  }
  .spanish-review__more {
    width: 100%;
    max-width: none;
  }
}
</style>
