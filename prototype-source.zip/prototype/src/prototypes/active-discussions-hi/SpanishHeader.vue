<script setup>
import { ref } from 'vue'
import { CdxButton, CdxIcon, CdxMenuButton, CdxSearchInput } from '@wikimedia/codex'
import {
  cdxIconMenu,
  cdxIconSearch,
  cdxIconBell,
  cdxIconUserAvatar,
  cdxIconWatchlist,
  cdxIconAppearance,
  cdxIconTray,
  cdxIconBookmarkList,
  cdxIconDownTriangle,
  cdxIconClose,
} from '@wikimedia/codex-icons'
const baseUrl = import.meta.env.BASE_URL
const query = ref(''),
  searchOpen = ref(false)
const menu = [
  { value: 'विकिपीडिया:मुखपृष्ठ', label: 'मुखपृष्ठ' },
  { value: 'विकिपीडिया:समाज मुखपृष्ठ', label: 'समाज मुखपृष्ठ' },
  { value: 'Special:RecentChanges', label: 'हाल में हुए परिवर्तन' },
  { value: 'Special:Random', label: 'यादृच्छिक लेख' },
  { value: 'विकिपीडिया:सहायता', label: 'सहायता' },
]
const account = [
  { value: 'Special:MyPage', label: 'सदस्य पृष्ठ' },
  { value: 'Special:MyTalk', label: 'वार्ता' },
  { value: 'Special:Contributions', label: 'योगदान' },
  { value: 'Special:Preferences', label: 'वरीयताएँ' },
]
function wiki(page) {
  if (page)
    window.open(
      'https://hi.wikipedia.org/wiki/' + encodeURIComponent(page.replace(/ /g, '_')),
      '_blank',
      'noopener',
    )
}
function search() {
  if (!query.value.trim()) return
  const url = new URL('https://hi.wikipedia.org/w/index.php')
  url.search = new URLSearchParams({ title: 'Special:Search', search: query.value })
  window.open(url.href, '_blank', 'noopener')
}
</script>
<template>
  <header class="spanish-header">
    <nav class="spanish-header__bar" aria-label="विकिपीडिया नेविगेशन">
      <CdxMenuButton
        :selected="null"
        :menu-items="menu"
        aria-label="मुख्य मेन्यू"
        weight="quiet"
        @update:selected="wiki"
        ><CdxIcon :icon="cdxIconMenu"
      /></CdxMenuButton>
      <a class="spanish-header__logo" :href="`${baseUrl}active-discussions-hi`" aria-label="मुखपृष्ठ पर जाएँ">
        <img
          class="spanish-header__globe"
          src="https://hi.wikipedia.org/static/images/icons/wikipedia.png"
          alt=""
          width="50"
          height="50"
        />
        <span class="spanish-header__wordmark"
          ><img
            src="https://hi.wikipedia.org/static/images/mobile/copyright/wikipedia-wordmark-hi.svg"
            alt="विकिपीडिया"
            width="120"
            height="18" /><img
            class="spanish-header__tagline"
            src="https://hi.wikipedia.org/static/images/mobile/copyright/wikipedia-tagline-hi.svg"
            alt="एक मुक्त ज्ञानकोश"
            width="120"
            height="13"
        /></span>
      </a>
      <form class="spanish-header__search" role="search" @submit.prevent="search">
        <CdxSearchInput
          v-model="query"
          aria-label="विकिपीडिया में खोजें"
          placeholder="विकिपीडिया में खोजें"
        /><CdxButton type="submit">खोजें</CdxButton>
      </form>
      <div class="spanish-header__tools">
        <CdxButton
          class="spanish-header__mobile-search"
          weight="quiet"
          :icon-only="true"
          aria-label="खोजें"
          @click="searchOpen = !searchOpen"
          ><CdxIcon :icon="cdxIconSearch"
        /></CdxButton>
        <a
          class="spanish-header__username"
          href="https://hi.wikipedia.org/wiki/Special:MyPage"
          target="_blank"
          rel="noopener"
          >परीक्षण सदस्य</a
        >
        <CdxButton class="spanish-header__desktop-tool" weight="quiet" :icon-only="true" aria-label="दिखावट" @click="wiki('Special:Preferences')"><CdxIcon :icon="cdxIconAppearance" /></CdxButton>
        <CdxButton
          weight="quiet"
          :icon-only="true"
          aria-label="सूचनाएँ"
          @click="wiki('Special:Notifications')"
          ><CdxIcon :icon="cdxIconBell"
        /></CdxButton>
        <CdxButton class="spanish-header__desktop-tool" weight="quiet" :icon-only="true" aria-label="संदेश" @click="wiki('Special:Notifications')"><CdxIcon :icon="cdxIconTray" /></CdxButton>
        <CdxButton class="spanish-header__desktop-tool" weight="quiet" :icon-only="true" aria-label="सहेजे गए पृष्ठ" @click="wiki('Special:Watchlist')"><CdxIcon :icon="cdxIconBookmarkList" /></CdxButton>
        <CdxButton
          class="spanish-header__watchlist"
          weight="quiet"
          :icon-only="true"
          aria-label="ध्यानसूची"
          @click="wiki('Special:Watchlist')"
          ><CdxIcon :icon="cdxIconWatchlist"
        /></CdxButton>
        <CdxMenuButton
          :selected="null"
          :menu-items="account"
          aria-label="व्यक्तिगत उपकरण"
          weight="quiet"
          @update:selected="wiki"
          ><CdxIcon :icon="cdxIconUserAvatar" /><CdxIcon class="spanish-header__caret" :icon="cdxIconDownTriangle" size="small" /></CdxMenuButton>
      </div>
    </nav>
    <form
      v-if="searchOpen"
      class="spanish-header__expanded-search"
      role="search"
      @submit.prevent="search"
    >
      <CdxSearchInput
        v-model="query"
        aria-label="विकिपीडिया में खोजें"
        placeholder="विकिपीडिया में खोजें"
      /><CdxButton type="submit">खोजें</CdxButton
      ><CdxButton
        weight="quiet"
        :icon-only="true"
        aria-label="खोज बंद करें"
        @click="searchOpen = false"
        ><CdxIcon :icon="cdxIconClose"
      /></CdxButton>
    </form>
  </header>
</template>
<style scoped>
.spanish-header {
  background: var(--background-color-base);
  color: var(--color-base);
}
.spanish-header__bar {
  max-width: 1600px;
  margin: auto;
  min-height: 80px;
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 8px 24px;
  box-sizing: border-box;
}
.spanish-header__logo {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-shrink: 0;
}
.spanish-header__wordmark {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.spanish-header__search {
  display: flex;
  align-items: center;
  flex: 1;
  max-width: 500px;
  margin: 0 24px;
}
.spanish-header__search > .cdx-search-input {
  flex: 1;
  min-width: 0;
}
.spanish-header__tools {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-left: auto;
}
.spanish-header__username {
  margin-right: 8px;
  white-space: nowrap;
}
.spanish-header__mobile-search {
  display: none;
}
.spanish-header__expanded-search {
  display: flex;
  padding: 8px 16px;
  gap: 8px;
}
@media (max-width: 1100px) {
  .spanish-header__search {
    display: none;
  }
  .spanish-header__mobile-search {
    display: inline-flex;
  }
  .spanish-header__globe {
    display: none;
  }
}
@media (max-width: 799px) {
  .spanish-header__bar {
    min-height: 56px;
    padding: 8px 16px;
    gap: 8px;
    background: var(--background-color-interactive-subtle);
  }
  .spanish-header__tagline,
  .spanish-header__username,
  .spanish-header__watchlist {
    display: none;
  }
  .spanish-header__tools {
    gap: 4px;
  }
  .spanish-header__wordmark img {
    width: 100px;
    height: 15px;
  }
}
/* Match the English dashboard chrome dimensions and tool order. */
@media (min-width: 800px) {
  .spanish-header__bar { max-width: none; min-height: 82px; padding: 8px 16px; gap: 16px; }
  .spanish-header__globe { display: none; }
  .spanish-header__logo { margin-left: 20px; }
  .spanish-header__wordmark { width: 152px; min-height: 44px; padding-block: 3px; gap: 2px; justify-content: space-between; }
  .spanish-header__wordmark img { width: auto; max-width: 100%; display: block; }
  .spanish-header__tools { gap: .2rem; }
  .spanish-header__username { font-size: 14px; margin-inline: 8px; }
  .spanish-header__tools :deep(.cdx-button) { height: 32px; min-width: 32px; padding: .5rem .4rem; }
  .spanish-header__search { max-width: 474px; margin: 0; padding-left: 24px; }
}
@media (min-width: 800px) and (max-width: 1120px) {
  .spanish-header__search { display: none; }
  .spanish-header__mobile-search { display: inline-flex; }
  .spanish-header__tools :deep(.cdx-button) { height: 40px; min-width: 40px; padding: .7rem; }
}
@media (max-width: 799px) {
 .spanish-header__desktop-tool, .spanish-header__caret { display: none; }
}
</style>
