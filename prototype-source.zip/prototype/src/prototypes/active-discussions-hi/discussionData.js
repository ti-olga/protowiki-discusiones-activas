export const WIKI_ORIGIN = 'https://hi.wikipedia.org'
export const groups = [
 ['समुदाय के पृष्ठ', [
 ['सहायता','विकिपीडिया के संपादन और इस्तेमाल के बारे में सवाल।'],
 ['चौपाल','समुदाय की सामान्य बातचीत, सुझाव और सूचनाएँ।'],
 ['सामुदायिक चर्चाएँ','समुदाय की राय और भागीदारी के लिए खुली चर्चाएँ।']]],
 ['वार्ता पृष्ठ', [
 ['सदस्य','विकिपीडिया के योगदानकर्ताओं के बीच बातचीत।'],
 ['लेख','लेखों को बेहतर बनाने के बारे में बातचीत।'],
 ['नीतियाँ और दिशानिर्देश','विकिपीडिया के नियमों के बारे में बातचीत।'],
 ['विकिपरियोजनाएँ','किसी विषय पर मिलकर काम करने का समन्वय।'],
 ['अन्य पृष्ठ','साँचे, चित्र, श्रेणियों और मॉड्यूल के बारे में बातचीत।']]],
 ['सूचनापट', [
 ['प्रबंधक सूचनापट','प्रबंधकों के ध्यान और कार्रवाई की ज़रूरत वाले अनुरोध।']]]
]
export const venues = {
 'सहायता':['विकिपीडिया:चौपाल'],
 'चौपाल':['विकिपीडिया:चौपाल'],
 'सामुदायिक चर्चाएँ':['विकिपीडिया:चौपाल'],
 'नीतियाँ और दिशानिर्देश':['विकिपीडिया:चौपाल'],
 'प्रबंधक सूचनापट':['विकिपीडिया:प्रबंधक सूचनापट'],
}
export async function wikiAPI(params, signal) {
  const url = new URL('/w/api.php', WIKI_ORIGIN)
  url.search = new URLSearchParams({ format: 'json', formatversion: '2', origin: '*', ...params })
  let response
  for (let attempt = 0; attempt < 3; attempt++) {
    response = await fetch(url, { cache: 'no-store', signal: signal || AbortSignal.timeout(25000) })
    if (response.status !== 429 || attempt === 2) break
    const retry = Number(response.headers.get('Retry-After'))
    const delay = Number.isFinite(retry) && retry > 0 ? retry * 1000 : 1500 * (attempt + 1)
    if (delay > 15000) break
    await new Promise((resolve) => setTimeout(resolve, delay))
  }
  if (!response.ok) throw Error('विकिपीडिया से यह स्थिति मिली: ' + response.status)
  const data = await response.json()
  if (data.error) {
    // A page can be deleted after appearing in recent changes. It has no live discussion.
    if (params.action === 'discussiontoolspageinfo' && /No current revision/.test(data.error.info || '')) return { discussiontoolspageinfo: { threaditemshtml: [] } }
    throw Error(data.error.info)
  }
  return data
}
export const wikiTextFromHTML = (html) =>
  new DOMParser()
    .parseFromString(html || '', 'text/html')
    .body.textContent.replace(/\s+/g, ' ')
    .trim()
export const isRecentDiscussion = (d) =>
  Number.isFinite(Number(d.latest)) &&
  d.latest > 0 &&
  Date.now() - d.latest >= 0 &&
  Date.now() - d.latest <= 30 * 86400000
export function discussionThreads(source, roots, type, interests = []) {
  const headings = []
  function find(items) {
    for (const item of items) {
      if (item.type === 'heading' && item.headingLevel === 2) headings.push(item)
      else if (item.type === 'heading') find(item.replies || [])
    }
  }
  find(roots)
  return headings
    .flatMap((thread) => {
      const comments = []
      function visit(item) {
        if (item.type === 'comment' && item.id && Number.isFinite(Date.parse(item.timestamp)))
          comments.push(item)
        for (const child of item.replies || []) visit(child)
      }
      visit(thread)
      if (!comments.length) return []
      comments.sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp))
      const title = wikiTextFromHTML(thread.html)
      if (!title) return []
      const body = comments.map((comment) => wikiTextFromHTML(comment.html)).join('\n\n')
      const topics =
        type === 'लेख'
          ? interests
          : interests.filter((interest) =>
              (title + ' ' + body)
                .toLocaleLowerCase('hi')
                .includes(interest.toLocaleLowerCase('hi')),
            )
      if (interests.length && !topics.length) return []
      const base = WIKI_ORIGIN + '/wiki/' + encodeURIComponent(source.replace(/ /g, '_'))
      return [
        {
          title,
          topicTitle: title,
          source,
          pageTitle: source,
          type,
          types: [type],
          topics,
          comments: Number.isInteger(thread.commentCount) ? thread.commentCount : comments.length,
          people: Number.isInteger(thread.authorCount)
            ? thread.authorCount
            : new Set(comments.map((c) => c.author).filter(Boolean)).size,
          latest: Date.parse(comments[0].timestamp),
          latestTimestamp: comments[0].timestamp,
          topicId: thread.id,
          topicName: thread.name,
          url: base + '#' + encodeURIComponent(title.replace(/ /g, '_')),
          body: body.slice(0, 2500),
          live: true,
          structured: true,
        },
      ]
    })
    .filter(isRecentDiscussion)
    .sort((a, b) => b.latest - a.latest)
}
const relative = new Intl.RelativeTimeFormat('hi', { numeric: 'always', style: 'short' })
export function relativeWikiTime(timestamp) {
  const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000))
  return seconds < 60
    ? relative.format(-seconds, 'second')
    : seconds < 3600
      ? relative.format(-Math.floor(seconds / 60), 'minute')
      : seconds < 86400
        ? relative.format(-Math.floor(seconds / 3600), 'hour')
        : relative.format(-Math.floor(seconds / 86400), 'day')
}
const namespaces = { 'सदस्य':'3', 'लेख':'1', 'विकिपरियोजनाएँ':'5', 'अन्य पृष्ठ':'7|11|13|15|829' }
export function createDiscussionLoader() {
  const cache = new Map(),
    queue = []
  let active = 0
  const drain = () => {
    while (active < 4 && queue.length) {
      const job = queue.shift()
      active++
      wikiAPI(job.params)
        .then(job.resolve, job.reject)
        .finally(() => {
          active--
          drain()
        })
    }
  }
  const api = (params) => {
    const key = JSON.stringify(params)
    if (!cache.has(key))
      cache.set(
        key,
        new Promise((resolve, reject) => {
          queue.push({ params, resolve, reject })
          drain()
        }),
      )
    return cache.get(key)
  }
  async function resolvePages(titles) {
    if (!titles.length) return []
    const data = await api({
      action: 'query',
      titles: titles.join('|'),
      redirects: 1,
      prop: 'info',
    })
    return (data.query?.pages || []).filter((p) => !p.missing).map((p) => p.title)
  }
  async function pagesForType(type, interests) {
    if (venues[type]) return resolvePages(venues[type])
    if (type === 'लेख' && interests.length)
      return resolvePages(interests.map((title) => 'वार्ता:' + title))
    if (namespaces[type]) {
      const changes = await api({
        action: 'query',
        list: 'recentchanges',
        rcnamespace: namespaces[type],
        rctype: 'edit|new',
        rcshow: '!bot',
        rcprop: 'title|timestamp',
        rclimit: '50',
      })
      return [...new Set((changes.query?.recentchanges || []).map((p) => p.title))]
        .filter((title) => !/पुरालेख|archive/i.test(title))
        .filter((title) => type !== 'विकिपरियोजनाएँ' || /विकिपरियोजना/.test(title))
        .slice(0, type === 'लेख' ? 10 : 6)
    }
    return []
  }
  async function pageThreads(page, type, interests) {
    const json = await api({ action: 'discussiontoolspageinfo', page, prop: 'threaditemshtml' })
    return discussionThreads(
      page,
      json.discussiontoolspageinfo?.threaditemshtml || [],
      type,
      interests,
    )
  }
  async function loadType(type, interests) {
    const pages = await pagesForType(type, interests)
    const results = await Promise.allSettled(
      pages.map((page) => pageThreads(page, type, interests)),
    )
    let rows = results.flatMap((r) => (r.status === 'fulfilled' ? r.value : []))
    if (type === 'सहायता') rows = rows.filter(row => /सहायता|मदद|अनुरोध|प्रश्न|सवाल/.test(row.title + ' ' + row.body))
    if (type === 'सामुदायिक चर्चाएँ') rows = rows.filter(row => /राय|मत|नीति|सहमति|चर्चा/.test(row.title + ' ' + row.body))
    if (type === 'नीतियाँ और दिशानिर्देश') rows = rows.filter(row => /नीति|नियम|दिशानिर्देश|सहमति/.test(row.title + ' ' + row.body))
    return { rows, failedPages: results.filter((r) => r.status === 'rejected').length, pages }
  }
  return { loadType, pageThreads, pagesForType }
}
export function mergeDiscussions(rows) {
  const merged = new Map()
  for (const row of rows) {
    const old = merged.get(row.url)
    merged.set(
      row.url,
      old
        ? {
            ...old,
            ...row,
            types: [...new Set([...old.types, ...row.types])],
            topics: [...new Set([...old.topics, ...row.topics])],
          }
        : row,
    )
  }
  return [...merged.values()]
}
