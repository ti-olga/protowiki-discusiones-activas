<script setup>
import { cdxIconPushPinFilled, prototypeIconFunnelFilled } from './icons'
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import {
  CdxAccordion,
  CdxButton,
  CdxCheckbox,
  CdxDialog,
  CdxField,
  CdxIcon,
  CdxMenuButton,
  CdxMessage,
  CdxMultiselectLookup,
  CdxProgressBar,
  CdxSelect,
  CdxToast,
  CdxToggleButtonGroup,
} from '@wikimedia/codex'
import {
  cdxIconEllipsis,
  cdxIconBell,
  cdxIconCollapse,
  cdxIconPrevious,
  cdxIconConfigure,
  cdxIconInfo,
} from '@wikimedia/codex-icons'
import DiscussionCard from './DiscussionCard.vue'
import {
  state,
  current,
  pinned,
  subscribed,
  ordered,
  setVersion,
  resetLimit,
  toggleSaved,
  ensureLoaded,
  loadDiscussions,
} from './discussionStore'
import { groups, wikiAPI } from './discussionData'
const props = defineProps({ fullQueue: { type: Boolean, default: false } })
const router = useRouter(),
  mobile = ref(window.innerWidth < 800)
const updateViewport = () => {
  mobile.value = window.innerWidth < 800
}
onMounted(() => {
  window.addEventListener('resize', updateViewport)
  ensureLoaded()
})
onUnmounted(() => {
  window.removeEventListener('resize', updateViewport)
  clearTimeout(searchTimer)
  searchController?.abort()
})
const isAccordion = computed(() => state.version === 'A')
const pinnedOpen = computed({
  get: () => !current.value.collapsed,
  set: (value) => (current.value.collapsed = !value),
})
const mainList = computed(() =>
  isAccordion.value
    ? ordered.value.filter((d) => !current.value.pins.includes(d.url))
    : ordered.value,
)
const visible = computed(() =>
  props.fullQueue ? mainList.value : mainList.value.slice(0, state.limit),
)
const canShowMore = computed(() => !props.fullQueue && visible.value.length < mainList.value.length)
const selectItems = [
  { value: 'all', label: 'All' },
  { value: 'subscribed', label: 'Subscribed' },
]
const toggles = computed(() =>
  state.version === 'B'
    ? [
        { value: 'all', label: 'All' },
        {
          value: 'pinned',
          label: 'Pinned',
          ariaLabel: 'Pinned, ' + pinned.value.length + ' discussions',
        },
        {
          value: 'subscribed',
          label: 'Subscribed',
          ariaLabel: 'Subscribed, ' + subscribed.value.length + ' discussions',
        },
      ]
    : [
        { value: 'all', label: 'All' },
        { value: 'subscribed', label: 'Subscribed' },
        { value: 'pinned', label: 'Pinned' },
      ],
)
const overflowItems = computed(() => [
  {
    value: 'interests',
    label: 'Interests',
    description: state.interests.length + ' selected',
    icon: cdxIconConfigure,
  },
  ...(state.version === 'A'
    ? [
        {
          value: 'types',
          label: 'Types of discussions',
          description: state.types.length + ' selected',
          icon: prototypeIconFunnelFilled,
        },
      ]
    : []),
  { value: 'about', label: 'About active discussions', icon: cdxIconInfo },
  {
    label: 'Prototype version',
    items: ['A', 'B', 'C', 'D'].map((version) => ({ value: version, label: 'Version ' + version })),
  },
])
const dialog = ref(''),
  draftTypes = ref([]),
  draftInterests = ref([]),
  inputChips = ref([]),
  interestOptions = ref([]),
  lookupValue = ref('')
function setting(value) {
  if (['A', 'B', 'C', 'D'].includes(value)) {
    setVersion(value)
    return
  }
  if (value === 'types') {
    draftTypes.value = [...state.types]
  }
  if (value === 'interests') {
    draftInterests.value = [...state.interests]
    inputChips.value = state.interests.map((value) => ({ value, label: value }))
    interestOptions.value = state.interests.map((value) => ({ value, label: value }))
  }
  dialog.value = value || ''
}
const dialogTitle = computed(
  () =>
    ({ types: 'Types of discussions', interests: 'Interests', about: 'About active discussions' })[
      dialog.value
    ],
)
function clearInterests() {
  draftInterests.value = []
  inputChips.value = []
}
function saveFilters() {
  if (dialog.value === 'types') state.types = [...draftTypes.value]
  if (dialog.value === 'interests') state.interests = [...draftInterests.value]
  dialog.value = ''
  loadDiscussions()
}
let searchTimer,
  searchController,
  searchGeneration = 0
watch(lookupValue, (value) => {
  clearTimeout(searchTimer)
  searchController?.abort()
  const generation = ++searchGeneration
  if (!String(value).trim()) {
    interestOptions.value = []
    return
  }
  searchTimer = setTimeout(async () => {
    try {
      searchController = new AbortController()
      const url = new URL('https://en.wikipedia.org/w/api.php')
      url.search = new URLSearchParams({
        action: 'opensearch',
        search: String(value),
        limit: '10',
        namespace: '0',
        format: 'json',
        origin: '*',
      })
      const response = await fetch(url, { signal: searchController.signal })
      const result = await response.json()
      if (generation === searchGeneration)
        interestOptions.value = result[1].map((value) => ({ value, label: value }))
    } catch (error) {
      if (error.name !== 'AbortError') interestOptions.value = []
    }
  }, 250)
})
watch(() => current.value.view, resetLimit)
const toast = ref(null)
function confirmation(title, body, link = false) {
  toast.value = { id: Date.now(), title, body, link }
}
function pin(d, deferRemoval = false) {
  const added = toggleSaved('pins', d, deferRemoval)
  confirmation(
    added ? 'Discussion pinned' : 'Discussion unpinned',
    added
      ? 'This discussion has moved to ‘Pinned’.'
      : 'This discussion has been removed from ‘Pinned’.',
  )
}
function subscribe(d, deferRemoval = false) {
  const added = toggleSaved('subscriptions', d, deferRemoval)
  const grouped = state.version === 'B' || state.version === 'C'
  confirmation(
    added ? 'You have subscribed!' : 'You have unsubscribed.',
    added
      ? grouped
        ? 'You’ll be notified of new comments on this topic, and the discussion has moved to ‘Subscribed’.'
        : 'You will receive notifications about new comments in this topic.'
      : grouped
        ? 'You’ll no longer be notified of new comments on this topic, and the discussion has been removed from ‘Subscribed’.'
        : 'You will no longer receive notifications about new comments in this topic.',
    added,
  )
}
function preference(d, delta) {
  state.preferences[d.url] = (state.preferences[d.url] || 0) + delta
  confirmation(
    'Preferences updated',
    delta > 0
      ? 'You’ll see more discussions like this.'
      : 'You’ll see fewer discussions like this.',
  )
}
function more() {
  if (mobile.value) {
    router.push('/active-discussions/queue')
    return
  }
  state.expanded = true
  state.limit = state.limit === 3 ? 10 : state.limit + 10
}
const emptyCopy = computed(() =>
  current.value.view === 'pinned'
    ? 'No pinned discussions yet. Use the card menu to pin a discussion.'
    : current.value.view === 'subscribed'
      ? 'No subscribed discussions yet. Use the card menu to subscribe.'
      : 'No discussions match these filters. Try another interest or discussion type.',
)
</script>
<template>
  <section
    class="active-discussions"
    :class="{ 'active-discussions--queue': fullQueue }"
    :data-version="state.version"
  >
    <div class="active-discussions__header">
      <CdxButton
        v-if="fullQueue"
        weight="quiet"
        :icon-only="true"
        aria-label="Back to dashboard"
        @click="router.push('/active-discussions')"
        ><CdxIcon :icon="cdxIconPrevious"
      /></CdxButton>
      <h2>Active discussions</h2>
      <div class="active-discussions__settings">
        <CdxButton
          v-if="state.version !== 'A'"
          class="active-discussions__filter"
          weight="quiet"
          :icon-only="true"
          :aria-label="'Filter types of discussions, ' + state.types.length + ' selected'"
          @click="setting('types')"
          ><span class="active-discussions__filter-symbol"><CdxIcon :icon="prototypeIconFunnelFilled" /><span v-if="state.types.length > 0"
              class="active-discussions__filter-count" aria-hidden="true">{{
            state.types.length
          }}</span></span></CdxButton
        >
        <CdxMenuButton
          :selected="null"
          :menu-items="overflowItems"
          weight="quiet"
          aria-label="Active discussions settings"
          @update:selected="setting"
          ><CdxIcon :icon="cdxIconEllipsis"
        /></CdxMenuButton>
      </div>
    </div>
    <div v-if="state.version === 'B' || state.version === 'C'" class="active-discussions__controls">
      <CdxToggleButtonGroup class="active-discussions__toggles" v-model="current.view" :buttons="toggles" aria-label="Discussion list">
        <template #default="{ button }">
          <template v-if="state.version === 'B' && button.value !== 'all'"
            ><CdxIcon
              :icon="button.value === 'pinned' ? cdxIconPushPinFilled : cdxIconBell"
            />
            <span v-if="(button.value === 'pinned' ? pinned.length : subscribed.length) > 1">{{
              button.value === 'pinned' ? pinned.length : subscribed.length
            }}</span></template
          >
          <template v-else
            >{{
              button.value === 'all' ? 'All' : button.value === 'pinned' ? 'Pinned' : 'Subscribed'
            }}<span v-if="state.version === 'C' && button.value !== 'all' && (button.value === 'pinned' ? pinned.length : subscribed.length) > 1">
              {{ button.value === 'pinned' ? pinned.length : subscribed.length }}</span
            ></template
          >
        </template>
      </CdxToggleButtonGroup>
    </div>
    <div v-if="state.version === 'D'" class="active-discussions__select">
      <CdxSelect
        v-model:selected="current.view"
        :menu-items="selectItems"
        aria-label="Discussion list"
      />
    </div>
    <div class="active-discussions__feed">
      <CdxAccordion
        v-if="isAccordion && pinned.length"
        v-model="pinnedOpen"
        separation="none"
        heading-level="h3"
        class="active-discussions__pinned"
      >
        <template #title>Pinned {{ pinned.length }}</template>
        <div class="active-discussions__cards">
          <DiscussionCard
            v-for="d in pinned"
            :key="d.url"
            :discussion="d"
            @pin="pin"
            @subscribe="subscribe"
            @prefer="preference($event, 1)"
            @less="preference($event, -1)"
          />
        </div>
      </CdxAccordion>
      <CdxMessage v-if="state.error" type="notice"
        >{{ state.error }}
        <CdxButton weight="quiet" @click="loadDiscussions">Retry</CdxButton></CdxMessage
      >
      <div
        v-if="state.busy"
        class="active-discussions__loading"
        aria-busy="true"
        aria-label="Loading discussions"
        role="status"
      >
        <CdxProgressBar inline aria-label="Loading discussions" />
        <div v-for="n in 3" :key="n" class="active-discussions__skeleton" aria-hidden="true">
          <div />
        </div>
        <CdxButton class="active-discussions__more" disabled>Show more</CdxButton>
      </div>
      <template v-else>
        <div class="active-discussions__cards">
          <DiscussionCard
            v-for="d in visible"
            :key="d.url"
            :discussion="d"
            @pin="pin"
            @subscribe="subscribe"
            @prefer="preference($event, 1)"
            @less="preference($event, -1)"
          />
        </div>
        <p
          v-if="!mainList.length && !(isAccordion && pinned.length)"
          class="active-discussions__empty"
          role="status"
        >
          {{ emptyCopy }}
        </p>
        <div v-if="!fullQueue" class="active-discussions__footer">
          <CdxButton v-if="canShowMore" class="active-discussions__more" @click="more"
            >Show more</CdxButton
          >
          <CdxButton
            v-if="!mobile && state.expanded"
            weight="quiet"
            :icon-only="true"
            aria-label="Collapse discussion cards"
            @click="resetLimit"
            ><CdxIcon :icon="cdxIconCollapse"
          /></CdxButton>
        </div>
      </template>
    </div>
    <CdxDialog
      :open="!!dialog"
      :title="dialogTitle || 'Active discussions'"
      :primary-action="
        dialog === 'about' ? undefined : { label: 'Apply', actionType: 'progressive' }
      "
      :default-action="{ label: dialog === 'about' ? 'Close' : 'Cancel' }"
      @update:open="
        (value) => {
          if (!value) dialog = ''
        }
      "
      @primary="saveFilters"
      @default="dialog = ''"
    >
      <template v-if="dialog === 'types'"
        ><p>
          Choose the types of discussions you want to follow. Leave all unchecked to include every
          type.
        </p>
        <CdxButton weight="quiet" @click="draftTypes = []">Clear all</CdxButton>
        <CdxField v-for="[group, items] in groups" :key="group" is-fieldset class="discussion-filter-group">
          <template #label>{{ group }}</template>
          <CdxCheckbox
            v-for="[type, description] in items"
            :key="type"
            v-model="draftTypes"
            :input-value="type"
            >{{ type }}<template #description>{{ description }}</template></CdxCheckbox
          >
        </CdxField></template
      >
      <CdxField v-else-if="dialog === 'interests'"
        ><template #label>Interests</template
        ><template #description
          >Search for articles or topics. Leave empty to include all interests.</template
        ><CdxMultiselectLookup
          v-model:selected="draftInterests"
          v-model:input-chips="inputChips"
          v-model:input-value="lookupValue"
          :menu-items="interestOptions"
          placeholder="Search Wikipedia"
          aria-label="Search interests"
        /><CdxButton weight="quiet" @click="clearInterests">Clear all</CdxButton></CdxField
      >
      <p v-else>
        Explore recent Wikipedia discussions, pin topics to return to, and subscribe to follow new
        comments. Discussions are limited to activity within the last 30 days. Pins and
        subscriptions in this prototype are saved in this browser.
      </p>
    </CdxDialog>
    <CdxToast
      v-if="toast"
      :key="toast.id"
      type="success"
      :auto-dismiss="toast.link ? 12000 : 6000"
      standalone
      @user-dismissed="toast = null"
      @auto-dismissed="toast = null"
      ><strong>{{ toast.title }}</strong>
      <p>
        {{ toast.body }}
        <a
          v-if="toast.link"
          class="discussion-subscriptions-link"
          href="https://en.wikipedia.org/wiki/Special:TopicSubscriptions"
          target="_blank"
          rel="noopener"
          >Open all subscribed topics.</a
        >
      </p></CdxToast
    >
  </section>
</template>
<style scoped>
.active-discussions {
  min-width: 0;
  color: var(--color-base);
}
.active-discussions__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.active-discussions__header h2 {
  margin: 0;
  padding: 0;
  font: var(--font-weight-bold) var(--font-size-x-large)/var(--line-height-x-large)
    var(--font-family-system-sans);
}
.active-discussions__settings {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}
.active-discussions__filter {
  position: relative;
  overflow: visible;
  width: 32px;
  min-width: 32px;
  height: 32px;
  padding: 5px;
}
.active-discussions__filter-symbol {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 20px;
  height: 20px;
}
.active-discussions__filter-count {
  position: absolute;
  right: 0;
  bottom: 0;
  transform: translate(40%, 35%);
  pointer-events: none;
  z-index: 2;
  box-sizing: border-box;
  min-width: 15px;
  height: 14px;
  padding: 0 2px;
  border: 1px solid var(--border-color-progressive);
  border-radius: 2px;
  background: var(--background-color-progressive-subtle);
  color: var(--color-progressive);
  font: 700 11px/12px var(--font-family-system-sans);
}
.active-discussions__controls {
  margin: 8px 0;
}
.active-discussions__select {
  width: 200px;
  max-width: 100%;
  margin: 12px 0;
}
.active-discussions[data-version='A'] .active-discussions__feed {
  margin-top: 12px;
}
.active-discussions__cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
}
.active-discussions__pinned {
  margin-bottom: 8px;
}
.active-discussions__empty {
  margin: 0;
  padding: 24px 0;
  color: var(--color-subtle);
  font-size: var(--font-size-medium);
}
.active-discussions__loading {
  display: flex;
  flex-direction: column;
  gap: 8px;
  position: relative;
}
.active-discussions__skeleton {
  height: 112px;
  padding: 12px;
  border: 1px solid var(--border-color-subtle);
  box-sizing: border-box;
}
.active-discussions__skeleton > div {
  height: 86px;
  width: 86px;
  border: 1px solid var(--border-color-subtle);
}
.active-discussions__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 8px;
}
.active-discussions__more {
  align-self: flex-start;
}
.discussion-filter-group {
  margin-block: var(--spacing-150);
}
.active-discussions--queue .active-discussions__header {
  height: 48px;
}
.active-discussions--queue .active-discussions__header h2 {
  font-size: var(--font-size-medium);
  text-align: center;
  flex: 1;
}
@media (max-width: 799px) {
  .active-discussions__more {
    width: 100%;
  }
  .active-discussions__footer {
    gap: 8px;
  }
  .active-discussions__header h2 {
    font-size: var(--font-size-large);
  }
}
.discussion-subscriptions-link {
  text-decoration: none;
}
.active-discussions--queue .active-discussions__header {
  position: relative;
  border-bottom: 1px solid var(--border-color-subtle);
}
.active-discussions--queue .active-discussions__header h2 {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  white-space: nowrap;
  pointer-events: none;
}
.active-discussions--queue .active-discussions__settings {
  margin-left: auto;
}
/* Preserve the reviewed 8px accordion padding and card spacing. */
.active-discussions__pinned :deep(summary) {
  padding: 8px;
}
.active-discussions__pinned :deep(.cdx-accordion__content) {
  padding: 8px 0 0;
}

.active-discussions__toggles { display:inline-flex; align-items:center; flex-wrap:wrap; vertical-align:middle; }

@media(max-width:799px){.active-discussions__more{width:100%;max-width:none;}}
</style>
