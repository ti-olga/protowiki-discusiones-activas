export const groups = [
  [
    'Community pages',
    [
      ['Teahouse', 'Help forum for new editors.'],
      ['Village pump', 'Central forum for policies, technical issues, and proposals'],
      ['Centralized discussion', 'Discussions seeking wider community input.'],
    ],
  ],
  [
    'Discussion pages',
    [
      ['User talk', 'Discussions between contributors'],
      ['Article talk', 'Discussions about improving the content and quality of an article'],
      ['Policy and guidelines', 'Discussions about policies and guidelines'],
      ['WikiProject', 'Topic-specific discussions'],
      ['Other talk pages', 'Discussions about templates, categories, files, and other pages'],
    ],
  ],
  [
    'Noticeboards',
    [
      ['Administrator', 'Forum for administrative issues and editor disputes'],
      ['Reliable source', 'Discussions about the reliability and suitability of sources used.'],
      [
        'Neutral point of view',
        'Discussions about the reliability and suitability of sources used.',
      ],
      [
        'Dispute resolution',
        'Discussions about neutrality, bias, and the balanced presentation of viewpoints.',
      ],
    ],
  ],
]
export const wikiPages = {
  'Centralized discussion': ['Wikipedia:Centralized discussion'],
  Teahouse: ['Wikipedia:Teahouse'],
  'Village pump': [
    'Wikipedia:Village pump (proposals)',
    'Wikipedia:Village pump (miscellaneous)',
    'Wikipedia:Village pump (technical)',
    'Wikipedia:Village pump (policy)',
    'Wikipedia:Village pump (idea lab)',
  ],
  'Policy and guidelines': [
    'Wikipedia talk:Verifiability',
    'Wikipedia talk:Reliable sources',
    'Wikipedia talk:No original research',
  ],
  Administrator: [
    "Wikipedia:Administrators' noticeboard",
    "Wikipedia:Administrators' noticeboard/Incidents",
  ],
  'Reliable source': ['Wikipedia:Reliable sources/Noticeboard'],
  'Neutral point of view': ['Wikipedia:Neutral point of view/Noticeboard'],
  'Dispute resolution': ['Wikipedia:Dispute resolution noticeboard'],
}
export async function wikiAPI(params) {
  const url = new URL('https://en.wikipedia.org/w/api.php')
  url.search = new URLSearchParams({ format: 'json', formatversion: '2', origin: '*', ...params })
  const response = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(20000) })
  if (!response.ok) throw Error('Wikipedia returned ' + response.status)
  const json = await response.json()
  if (json.error) throw Error(json.error.info)
  return json
}
export function wikiTextFromHTML(html) {
  return new DOMParser()
    .parseFromString(html || '', 'text/html')
    .body.textContent.replace(/\s+/g, ' ')
    .trim()
}
export function discussionThreads(source, roots, type, interests, all = false) {
  const topics = []
  function collect(items) {
    for (const item of items) {
      if (item.type === 'heading' && item.headingLevel === 2) topics.push(item)
      else if (item.type === 'heading') collect(item.replies || [])
    }
  }
  collect(roots)
  return topics
    .flatMap((thread) => {
      const comments = []
      function visit(item) {
        if (item.type === 'comment' && item.id && Number.isFinite(Date.parse(item.timestamp)))
          comments.push(item)
        for (const child of item.replies || []) visit(child)
      }
      visit(thread)
      if (!comments.length) return []
      comments.sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp))
      const latest = comments[0]
      const title = wikiTextFromHTML(thread.html)
      if (!title) return []
      const body = comments.map((comment) => wikiTextFromHTML(comment.html)).join('\n\n')
      const relevant =
        type === 'Article talk'
          ? interests
          : interests.filter((interest) =>
              (title + ' ' + body).toLowerCase().includes(interest.toLowerCase()),
            )
      if (interests.length && !relevant.length) return []
      const base = 'https://en.wikipedia.org/wiki/' + encodeURIComponent(source.replace(/ /g, '_'))
      return [
        {
          title,
          topicTitle: title,
          source,
          pageTitle: source,
          type,
          topics: relevant,
          comments: Number.isInteger(thread.commentCount) ? thread.commentCount : comments.length,
          people: Number.isInteger(thread.authorCount)
            ? thread.authorCount
            : new Set(comments.map((comment) => comment.author).filter(Boolean)).size,
          latest: Date.parse(latest.timestamp),
          latestTimestamp: latest.timestamp,
          latestCommentId: latest.id,
          topicId: thread.id,
          topicName: thread.name,
          url: base + '#' + encodeURIComponent(title.replace(/ /g, '_')),
          latestCommentUrl: base + '#' + encodeURIComponent(latest.id),
          body: body.slice(0, 1800),
          live: true,
          structured: true,
        },
      ]
    })
    .filter(isRecentDiscussion)
    .sort((a, b) => b.latest - a.latest)
    .slice(0, all ? undefined : 15)
}
export function isRecentDiscussion(d) {
  const age = Date.now() - Number(d.latest)
  return Number.isFinite(age) && Number(d.latest) > 0 && age >= 0 && age <= 30 * 24 * 60 * 60 * 1000
}
export function relativeWikiTime(t) {
  const seconds = Math.max(0, Math.floor((Date.now() - t) / 1000))
  if (seconds < 60) return seconds + 's'
  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return minutes + 'm'
  const hours = Math.floor(minutes / 60)
  return hours < 24 ? hours + 'h' : Math.floor(hours / 24) + 'd'
}
export async function pagesForType(type, interests) {
  if (wikiPages[type]) return wikiPages[type]
  if (type === 'Article talk' && interests.length) return interests.map((t) => 'Talk:' + t)
  const namespace = {
    'User talk': '3',
    'Article talk': '1',
    WikiProject: '4',
    'Other talk pages': '11|15|101',
  }[type]
  if (!namespace) return []
  const query =
    (interests.length
      ? interests.map((t) => '"' + t.replace(/"/g, '') + '"').join(' OR ')
      : 'discussion') + (type === 'WikiProject' ? ' prefix:Wikipedia:WikiProject' : '')
  const result = await wikiAPI({
    action: 'query',
    list: 'search',
    srsearch: query,
    srnamespace: namespace,
    srlimit: '4',
  })
  return result.query.search.map((p) => p.title)
}
export async function loadCentralizedDiscussions(interests) {
  const index = await wikiAPI({
    action: 'parse',
    page: 'Template:Centralized discussion',
    prop: 'wikitext',
  })
  const entries = [
    ...(index.parse?.wikitext || '').matchAll(/^\*\s*\[\[(Wikipedia:[^\]|]+)(?:\|[^\]]*)?\]\]/gm),
  ].map((match) => {
    const [page, anchor] = match[1].split('#')
    return { page, anchor }
  })
  const normalize = (text) => text.replace(/_/g, ' ').trim().toLowerCase()
  const results = await Promise.allSettled(
    entries.map(async (entry) => {
      const result = await wikiAPI({
        action: 'discussiontoolspageinfo',
        page: entry.page,
        prop: 'threaditemshtml',
      })
      const records = discussionThreads(
        entry.page,
        result.discussiontoolspageinfo?.threaditemshtml || [],
        'Centralized discussion',
        interests,
        true,
      )
      return entry.anchor
        ? records.filter((row) => normalize(row.title) === normalize(entry.anchor))
        : records
    }),
  )
  return results.flatMap((result) => (result.status === 'fulfilled' ? result.value : []))
}
