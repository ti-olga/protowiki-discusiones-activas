// Filled pin retained from the approved prototype; Codex currently ships only its outline variant.
export const cdxIconPushPinFilled =
  '<path d="M13 8V2a2 2 0 0 0 2-2H5a2 2 0 0 0 2 2v6H6a2 2 0 0 0-2 2v1h5v5l1 4 1-4v-5h5v-1a2 2 0 0 0-2-2z"/>'

// Prototype-only filled variant of Codex's 20×20 funnel silhouette.
export const prototypeIconFunnelFilled =
  '<path d="M1 1h18v2.63l-6 7.71V19H7v-7.66L1 3.63z"/>'
