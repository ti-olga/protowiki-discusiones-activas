<script setup>
import { watch, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import DashboardPage from './DashboardPage.vue'
import { setVersion } from './discussionStore'
definePage({ meta: { platform: 'web', hidden: true } })
const route = useRoute()
const oldLang=document.documentElement.lang, oldDir=document.documentElement.dir
document.documentElement.lang='en'; document.documentElement.dir='ltr'
watch(()=>route.query.version, value=>{if(['A','B','C','D'].includes(value))setVersion(value)}, {immediate:true})
onUnmounted(()=>{document.documentElement.lang=oldLang;document.documentElement.dir=oldDir})
</script>
<template><DashboardPage /></template>
