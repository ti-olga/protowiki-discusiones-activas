<script setup>
import { watch, onUnmounted } from 'vue'
import { useRoute } from 'vue-router'
import DashboardPage from './DashboardPage.vue'
import { setVersion } from './discussionStore'
definePage({ meta: { platform: 'web', hidden: true } })
const route = useRoute()
watch(()=>route.query.version, value=>{if(['A','B','C','D'].includes(value))setVersion(value)}, {immediate:true})

</script>
<template><DashboardPage /></template>
