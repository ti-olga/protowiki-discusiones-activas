// Translate the earlier standalone prototype's numeric card IDs and swapped C/D
// implementation keys into the native dashboard's stable discussion URLs.
export function migrateLegacyState(legacy) {
  if (!legacy || typeof legacy !== 'object') return {}
  const records = [...new Map([
    ...(legacy.liveRecords || []), ...(legacy.aPinnedRecords || []), ...(legacy.dPinnedRecords || []),
  ].filter(d=>d?.url).map(d=>[d.url,d])).values()]
  const idsToUrls = ids => [...new Set((ids || []).map(id=>records.find(d=>d.id===id)?.url).filter(Boolean))]
  const version = (pins, subscriptions, view='all', collapsed=false) => ({pins:idsToUrls(pins),subscriptions:idsToUrls(subscriptions),view:view==='new'?'all':view,collapsed})
  return {
    version:legacy.version==='C'?'D':legacy.version==='D'?'C':legacy.version||'A',
    types:legacy.types||[],interests:legacy.interests||[],
    versions:{
      A:version(legacy.pins,legacy.subscriptions,'all',!!legacy.aPinsCollapsed),
      B:version(legacy.bPins,legacy.bSubscriptions,legacy.bTab||'all'),
      C:version(legacy.dPins,legacy.dSubscriptions,legacy.dView||'all'),
      D:version(legacy.cPins,legacy.cSubscriptions,legacy.cView||'all'),
    },
    records,liveUrls:legacy.liveUrls||records.map(d=>d.url),opened:legacy.openedDiscussions||{},
    preferences:Object.fromEntries(Object.entries(legacy.preferences||{}).flatMap(([id,value])=>{const record=records.find(d=>d.id===Number(id));return record?[[record.url,value]]:[]})),
  }
}
