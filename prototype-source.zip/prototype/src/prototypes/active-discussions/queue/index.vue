<script setup>
import DashboardPage from '../DashboardPage.vue'
definePage({ meta: { hidden: true, platform: 'web' } })
</script>
<template><DashboardPage full-queue /></template>
