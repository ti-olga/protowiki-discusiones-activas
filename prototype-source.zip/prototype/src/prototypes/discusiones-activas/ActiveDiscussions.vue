<script setup>
import { cdxIconPushPinFilled, prototypeIconFunnelFilled } from './icons'
import { computed, onMounted, onUnmounted, ref, watch } from 'vue'
import { useRouter } from 'vue-router'
import {
  CdxButton,
  CdxCheckbox,
  CdxDialog,
  CdxField,
  CdxIcon,
  CdxMenuButton,
  CdxMessage,
  CdxMultiselectLookup,
  CdxProgressBar,
  CdxToast,
  CdxToggleButtonGroup,
} from '@wikimedia/codex'
import {
  cdxIconEllipsis,
  cdxIconBell,
  cdxIconCollapse,
  cdxIconPrevious,
  cdxIconConfigure,
  cdxIconInfo,
  cdxIconClose,
} from '@wikimedia/codex-icons'
import DiscussionCard from './DiscussionCard.vue'
import {
  state,
  current,
  pinned,
  subscribed,
  ordered,
  resetLimit,
  toggleSaved,
  ensureLoaded,
  loadDiscussions,
} from './discussionStore'
import { groups, WIKI_ORIGIN } from './discussionData'
const props = defineProps({ fullQueue: { type: Boolean, default: false } })
const router = useRouter(),
  mobile = ref(innerWidth < 800)
const updateViewport = () => (mobile.value = innerWidth < 800)
onMounted(() => {
  addEventListener('resize', updateViewport)
  ensureLoaded()
})
onUnmounted(() => {
  removeEventListener('resize', updateViewport)
  clearTimeout(searchTimer)
  searchController?.abort()
})
const mainList = ordered
const visible = computed(() =>
  props.fullQueue ? mainList.value : mainList.value.slice(0, state.limit),
)
const canShowMore = computed(() => !props.fullQueue && visible.value.length < mainList.value.length)
const toggles = computed(() => [
  { value: 'all', label: 'Todas', ariaLabel: 'Todas las discusiones' },
  { value: 'pinned', label: 'Fijadas', ariaLabel: 'Discusiones fijadas: ' + pinned.value.length },
  {
    value: 'subscribed',
    label: 'Suscritas',
    ariaLabel: 'Discusiones suscritas: ' + subscribed.value.length,
  },
])
const overflowItems = computed(() => [
  {
    value: 'interests',
    label: 'Intereses',
    description:
      state.interests.length + (state.interests.length === 1 ? ' seleccionado' : ' seleccionados'),
    icon: cdxIconConfigure,
  },
  { value: 'about', label: 'Acerca de las discusiones activas', icon: cdxIconInfo },
])
const dialog = ref(''),
  draftTypes = ref([]),
  draftInterests = ref([]),
  inputChips = ref([]),
  interestOptions = ref([]),
  lookupValue = ref('')
function setting(value) {
  if (value === 'types') draftTypes.value = [...state.types]
  if (value === 'interests') {
    draftInterests.value = [...state.interests]
    inputChips.value = state.interests.map((value) => ({ value, label: value }))
    interestOptions.value = state.interests.map((value) => ({ value, label: value }))
  }
  dialog.value = value || ''
}
const dialogTitle = computed(
  () =>
    ({
      types: 'Tipos de discusión',
      interests: 'Intereses',
      about: 'Acerca de las discusiones activas',
    })[dialog.value],
)
function clearInterests() {
  draftInterests.value = []
  inputChips.value = []
}
function saveFilters() {
  if (dialog.value === 'types') state.types = [...draftTypes.value]
  if (dialog.value === 'interests') state.interests = [...draftInterests.value]
  dialog.value = ''
  loadDiscussions()
}
let searchTimer,
  searchController,
  searchGeneration = 0
watch(lookupValue, (value) => {
  clearTimeout(searchTimer)
  searchController?.abort()
  const generation = ++searchGeneration
  if (!String(value).trim()) {
    interestOptions.value = []
    return
  }
  searchTimer = setTimeout(async () => {
    try {
      searchController = new AbortController()
      const url = new URL('/w/api.php', WIKI_ORIGIN)
      url.search = new URLSearchParams({
        action: 'opensearch',
        search: String(value),
        limit: '10',
        namespace: '0',
        format: 'json',
        origin: '*',
      })
      const response = await fetch(url, { signal: searchController.signal })
      const result = await response.json()
      if (generation === searchGeneration)
        interestOptions.value = result[1].map((value) => ({ value, label: value }))
    } catch (error) {
      if (error.name !== 'AbortError') interestOptions.value = []
    }
  }, 250)
})
watch(() => current.value.view, resetLimit)
const toast = ref(null)
function confirmation(title, body, link = false) {
  toast.value = { id: Date.now(), title, body, link }
}
function pin(d, deferRemoval = false) {
  toggleSaved('pins', d, deferRemoval)
}
function subscribe(d, deferRemoval = false) {
  toggleSaved('subscriptions', d, deferRemoval)
}
function preference(d, delta) {
  state.preferences[d.url] = (state.preferences[d.url] || 0) + delta
  confirmation(
    'Preferencias actualizadas',
    delta > 0
      ? 'Se mostrarán más discusiones de este tipo.'
      : 'Se mostrarán menos discusiones de este tipo.',
  )
}
function more() {
  if (mobile.value) {
    router.push('/discusiones-activas/cola')
    return
  }
  state.expanded = true
  state.limit = state.limit === 3 ? 10 : state.limit + 10
}
const emptyCopy = computed(() =>
  current.value.view === 'pinned'
    ? 'Aún no has fijado ninguna discusión. Usa el menú de una tarjeta para fijarla.'
    : current.value.view === 'subscribed'
      ? 'Aún no te has suscrito a ninguna discusión. Usa el menú de una tarjeta para suscribirte.'
      : 'No hay discusiones que coincidan con estos filtros. Prueba con otros intereses o tipos de discusión.',
)
</script>
<template>
  <section
    class="active-discussions"
    :class="{ 'active-discussions--queue': fullQueue }"
    data-version="B"
  >
    <div class="active-discussions__header">
      <CdxButton
        v-if="fullQueue"
        weight="quiet"
        :icon-only="true"
        aria-label="Volver al inicio"
        @click="router.push('/discusiones-activas')"
        ><CdxIcon :icon="cdxIconPrevious"
      /></CdxButton>
      <h2>Discusiones activas</h2>
      <div class="active-discussions__settings">
        <CdxButton
          class="active-discussions__filter"
          weight="quiet"
          :icon-only="true"
          :aria-label="
            'Filtrar tipos de discusión: ' +
            state.types.length +
            (state.types.length === 1 ? ' seleccionado' : ' seleccionados')
          "
          @click="setting('types')"
          ><span class="active-discussions__filter-symbol"
            ><CdxIcon :icon="prototypeIconFunnelFilled" /><span
              v-if="state.types.length > 0"
              class="active-discussions__filter-count"
              aria-hidden="true"
              >{{ state.types.length }}</span
            ></span
          ></CdxButton
        >
        <CdxMenuButton
          :selected="null"
          :menu-items="overflowItems"
          weight="quiet"
          aria-label="Opciones de discusiones activas"
          @update:selected="setting"
          ><CdxIcon :icon="cdxIconEllipsis"
        /></CdxMenuButton>
      </div>
    </div>
    <div class="active-discussions__controls">
      <CdxToggleButtonGroup
        class="active-discussions__toggles"
        v-model="current.view"
        :buttons="toggles"
        aria-label="Lista de discusiones"
      >
        <template #default="{ button }"
          ><template v-if="button.value === 'all'">Todas</template
          ><template v-else
            ><CdxIcon
              :icon="button.value === 'pinned' ? cdxIconPushPinFilled : cdxIconBell"
            /><span v-if="(button.value === 'pinned' ? pinned.length : subscribed.length) > 0">{{
              button.value === 'pinned' ? pinned.length : subscribed.length
            }}</span></template
          ></template
        >
      </CdxToggleButtonGroup>
    </div>
    <div class="active-discussions__feed">
      <CdxMessage v-if="state.error" type="notice"
        >{{ state.error }}
        <CdxButton weight="quiet" @click="loadDiscussions">Reintentar</CdxButton></CdxMessage
      >
      <div
        v-if="state.busy"
        class="active-discussions__loading"
        aria-busy="true"
        aria-label="Cargando discusiones"
        role="status"
      >
        <CdxProgressBar inline aria-label="Cargando discusiones" />
        <div v-for="n in 3" :key="n" class="active-discussions__skeleton" aria-hidden="true">
          <div />
        </div>
        <CdxButton class="active-discussions__more" disabled>Mostrar más</CdxButton>
      </div>
      <template v-else>
        <div class="active-discussions__cards">
          <DiscussionCard
            v-for="d in visible"
            :key="d.url"
            :discussion="d"
            @pin="pin"
            @subscribe="subscribe"
            @prefer="preference($event, 1)"
            @less="preference($event, -1)"
          />
        </div>
        <p v-if="!mainList.length" class="active-discussions__empty" role="status">
          {{ emptyCopy }}
        </p>
        <div v-if="!fullQueue" class="active-discussions__footer">
          <CdxButton v-if="canShowMore" class="active-discussions__more" @click="more"
            >Mostrar más</CdxButton
          >
          <CdxButton
            v-if="!mobile && state.expanded"
            weight="quiet"
            :icon-only="true"
            aria-label="Contraer las discusiones"
            @click="resetLimit"
            ><CdxIcon :icon="cdxIconCollapse"
          /></CdxButton>
        </div>
      </template>
    </div>
    <CdxDialog
      use-close-button
      close-button-label="Cerrar"
      :open="!!dialog"
      :title="dialogTitle || 'Discusiones activas'"
      :primary-action="
        dialog === 'about' ? undefined : { label: 'Aplicar', actionType: 'progressive' }
      "
      :default-action="{ label: dialog === 'about' ? 'Cerrar' : 'Cancelar' }"
      @update:open="
        (value) => {
          if (!value) dialog = ''
        }
      "
      @primary="saveFilters"
      @default="dialog = ''"
    >
      <template v-if="dialog === 'types'"
        >
        <CdxField v-for="[group, items] in groups" :key="group" is-fieldset class="discussion-filter-group">
          <template #label>{{ group }}</template>
          <CdxCheckbox
            v-for="[type, description] in items"
            :key="type"
            v-model="draftTypes"
            :input-value="type"
            >{{ type }}<template #description>{{ description }}</template></CdxCheckbox
          >
        </CdxField></template
      >
      <CdxField v-else-if="dialog === 'interests'"
        ><template #label>Intereses</template
        ><template #description
          >Busca artículos o temas. Deja el campo vacío para incluir todos los intereses.</template
        ><CdxMultiselectLookup
          v-model:selected="draftInterests"
          v-model:input-chips="inputChips"
          v-model:input-value="lookupValue"
          :menu-items="interestOptions"
          placeholder="Buscar en Wikipedia"
          aria-label="Buscar intereses"
          ><template #no-results>No se han encontrado resultados.</template></CdxMultiselectLookup
        ><CdxButton weight="quiet" @click="clearInterests">Borrar todo</CdxButton></CdxField
      >
      <p v-else>
        Explora las conversaciones de Wikipedia en español de los últimos 30 días. Fija temas para
        encontrarlos más tarde y suscríbete para seguir nuevos comentarios.
      </p>
    </CdxDialog>
    <CdxToast
      v-if="toast"
      :key="toast.id"
      type="success"
      :auto-dismiss="toast.link ? 12000 : 6000"
      standalone
      prevent-user-dismiss
      @user-dismissed="toast = null"
      @auto-dismissed="toast = null"
      ><div class="spanish-toast-heading">
        <strong>{{ toast.title }}</strong
        ><CdxButton weight="quiet" :icon-only="true" aria-label="Cerrar" @click="toast = null"
          ><CdxIcon :icon="cdxIconClose"
        /></CdxButton>
      </div>
      <p>
        {{ toast.body }}
        <a
          v-if="toast.link"
          class="discussion-subscriptions-link"
          href="https://es.wikipedia.org/wiki/Special:TopicSubscriptions?uselang=es"
          target="_blank"
          rel="noopener"
          >Abrir todos los temas suscritos.</a
        >
      </p></CdxToast
    >
  </section>
</template>
<style scoped>
.active-discussions {
  min-width: 0;
  color: var(--color-base);
}
.active-discussions__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
.active-discussions__header h2 {
  margin: 0;
  padding: 0;
  font: var(--font-weight-bold) var(--font-size-x-large)/var(--line-height-x-large)
    var(--font-family-system-sans);
}
.active-discussions__settings {
  display: flex;
  align-items: center;
  gap: 12px;
  flex-shrink: 0;
}
.active-discussions__filter {
  position: relative;
  overflow: visible;
  width: 32px;
  min-width: 32px;
  height: 32px;
  padding: 5px;
}
.active-discussions__filter-symbol {
  position: relative;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  width: 20px;
  height: 20px;
}
.active-discussions__filter-count {
  position: absolute;
  right: 0;
  bottom: 0;
  transform: translate(40%, 35%);
  pointer-events: none;
  z-index: 2;
  box-sizing: border-box;
  min-width: 15px;
  height: 14px;
  padding: 0 2px;
  border: 1px solid var(--border-color-progressive);
  border-radius: 2px;
  background: var(--background-color-progressive-subtle);
  color: var(--color-progressive);
  font: 700 11px/12px var(--font-family-system-sans);
}
.active-discussions__controls {
  margin: 8px 0;
}
.active-discussions__select {
  width: 200px;
  max-width: 100%;
  margin: 12px 0;
}
.active-discussions[data-version='A'] .active-discussions__feed {
  margin-top: 12px;
}
.active-discussions__cards {
  display: flex;
  flex-direction: column;
  gap: 8px;
  min-width: 0;
}
.active-discussions__pinned {
  margin-bottom: 8px;
}
.active-discussions__empty {
  margin: 0;
  padding: 24px 0;
  color: var(--color-subtle);
  font-size: var(--font-size-medium);
}
.active-discussions__loading {
  display: flex;
  flex-direction: column;
  gap: 8px;
  position: relative;
}
.active-discussions__skeleton {
  height: 112px;
  padding: 12px;
  border: 1px solid var(--border-color-subtle);
  box-sizing: border-box;
}
.active-discussions__skeleton > div {
  height: 86px;
  width: 86px;
  border: 1px solid var(--border-color-subtle);
}
.active-discussions__footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: 8px;
}
.active-discussions__more {
  align-self: flex-start;
}
.discussion-filter-group {
  margin-block: var(--spacing-150);
}
.active-discussions--queue .active-discussions__header {
  height: 48px;
}
.active-discussions--queue .active-discussions__header h2 {
  font-size: var(--font-size-medium);
  text-align: center;
  flex: 1;
}
@media (max-width: 799px) {
  .active-discussions__more {
    width: 100%;
  }
  .active-discussions__footer {
    gap: 8px;
  }
  .active-discussions__header h2 {
    font-size: var(--font-size-large);
  }
}
.discussion-subscriptions-link {
  text-decoration: none;
}
.active-discussions--queue .active-discussions__header {
  position: relative;
  border-bottom: 1px solid var(--border-color-subtle);
}
.active-discussions--queue .active-discussions__header h2 {
  position: absolute;
  left: 50%;
  transform: translateX(-50%);
  white-space: nowrap;
  pointer-events: none;
}
.active-discussions--queue .active-discussions__settings {
  margin-left: auto;
}
/* Preserve the reviewed 8px accordion padding and card spacing. */
.active-discussions__pinned :deep(summary) {
  padding: 8px;
}
.active-discussions__pinned :deep(.cdx-accordion__content) {
  padding: 8px 0 0;
}

.active-discussions__toggles {
  display: inline-flex;
  align-items: center;
  flex-wrap: wrap;
  vertical-align: middle;
}

@media (max-width: 799px) {
  .active-discussions__more {
    width: 100%;
    max-width: none;
  }
}
.spanish-toast-heading {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}
</style>
