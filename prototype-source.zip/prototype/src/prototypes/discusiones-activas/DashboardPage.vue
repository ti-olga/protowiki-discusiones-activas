<script setup>
import { onMounted, onUnmounted, provide, ref } from 'vue'
import { CdxAccordion, CdxIcon } from '@wikimedia/codex'
import { cdxIconUserTalk, cdxIconCheck } from '@wikimedia/codex-icons'
import ChromeWrapper from '@/components/chrome/ChromeWrapper.vue'
import SpecialPageWrapper from '@/components/SpecialPageWrapper.vue'
import Dashboard from '@/components/dashboard/Dashboard.vue'
import DashboardModule from '@/components/dashboard/DashboardModule.vue'
import ActiveDiscussions from './ActiveDiscussions.vue'
import ReviewChanges from './ReviewChanges.vue'
import SpanishHeader from './SpanishHeader.vue'
const props = defineProps({ fullQueue: { type: Boolean, default: false } })
const translations = {
  'cdx-input-chip-aria-description': 'Pulsa Intro para editar o Supr para eliminar',
  'cdx-dialog-close-button-label': 'Cerrar',
  'cdx-message-dismiss-button-label': 'Cerrar',
  'cdx-popover-close-button-label': 'Cerrar',
  'cdx-label-optional-flag': '(opcional)',
  'cdx-search-input-search-button-label': 'Buscar',
  'cdx-typeahead-search-search-results-label': 'Resultados de la búsqueda',
}
provide('CdxI18nFunction', (key) => translations[key])
const mobile = ref(innerWidth < 800),
  oldLang = document.documentElement.lang,
  oldDir = document.documentElement.dir,
  oldTitle = document.title
const resize = () => (mobile.value = innerWidth < 800)
onMounted(() => {
  document.documentElement.lang = 'es'
  document.documentElement.dir = 'ltr'
  document.title = 'Discusiones activas — Wikipedia'
  addEventListener('resize', resize)
})
onUnmounted(() => {
  document.documentElement.lang = oldLang
  document.documentElement.dir = oldDir
  document.title = oldTitle
  removeEventListener('resize', resize)
})
const policies = [
  [
    'Punto de vista neutral',
    'Los artículos deben presentar de forma equilibrada los puntos de vista publicados en fuentes fiables.',
  ],
  [
    'Verificabilidad',
    'La información debe poder comprobarse mediante referencias a fuentes publicadas.',
  ],
  ['Fuentes fiables', 'Utiliza fuentes publicadas, independientes y de calidad.'],
  ['Presume buena fe', 'Supón que las demás personas quieren mejorar Wikipedia.'],
]
</script>
<template>
  <ChromeWrapper
    v-if="!fullQueue"
    lang="es"
    dir="ltr"
    :skin="mobile ? 'mobile' : 'desktop'"
    :last-edited-notice="false"
    :prototyping-settings="false"
  >
    <template #header><SpanishHeader /></template>
    <SpecialPageWrapper title="¡Hola, Usuario de prueba!">
      <Dashboard class="spanish-dashboard">
        <template v-if="mobile" #mobile
          ><ActiveDiscussions /><ReviewChanges />
          <DashboardModule title="Tu impacto"
            ><div class="spanish-impact">
              <span><CdxIcon :icon="cdxIconUserTalk" /> <strong>3</strong> Agradecimientos enviados</span
              ><span><CdxIcon :icon="cdxIconCheck" /> <strong>62</strong> Ediciones revisadas</span>
            </div></DashboardModule
          >
        </template>
        <template v-if="!mobile" #primary><ActiveDiscussions /><ReviewChanges /></template>
        <template v-if="!mobile" #sidebar
          ><DashboardModule title="Tu impacto"
            ><div class="spanish-impact">
              <span><CdxIcon :icon="cdxIconUserTalk" /> <strong>3</strong> Agradecimientos enviados</span
              ><span><CdxIcon :icon="cdxIconCheck" /> <strong>62</strong> Ediciones revisadas</span>
            </div></DashboardModule
          ><DashboardModule title="Políticas y convenciones"
            ><CdxAccordion v-for="[title, body] in policies" :key="title" separation="none"
              ><template #title>{{ title }}</template
              >{{ body }}</CdxAccordion
            ></DashboardModule
          ></template
        >
      </Dashboard>
    </SpecialPageWrapper>
    <template #footer
      ><footer class="spanish-footer" lang="es">
        <p>Prototipo para pruebas de usabilidad. Las acciones no modifican Wikipedia.</p>
        <nav aria-label="Información de Wikipedia">
          <a
            href="https://foundation.wikimedia.org/wiki/Policy:Privacy_policy/es"
            target="_blank"
            rel="noopener"
            >Política de privacidad</a
          ><a
            href="https://es.wikipedia.org/wiki/Wikipedia:Acerca_de"
            target="_blank"
            rel="noopener"
            >Acerca de Wikipedia</a
          ><a
            href="https://es.wikipedia.org/wiki/Wikipedia:Limitaci%C3%B3n_general_de_responsabilidad"
            target="_blank"
            rel="noopener"
            >Limitación de responsabilidad</a
          ><a
            href="https://foundation.wikimedia.org/wiki/Policy:Terms_of_Use/es"
            target="_blank"
            rel="noopener"
            >Términos de uso</a
          >
        </nav>
      </footer></template
    >
  </ChromeWrapper>
  <main dir="ltr" v-else class="spanish-full-queue" lang="es" :data-skin="mobile ? 'mobile' : 'desktop'">
    <ActiveDiscussions full-queue />
  </main>
</template>
<style scoped>
.spanish-impact {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.spanish-impact > span {
  display: flex;
  align-items: center;
  gap: 8px;
}
.spanish-full-queue {
  max-width: 860px;
  margin: 0 auto;
  padding: 0 16px 24px;
}
.spanish-footer {
  padding: 24px;
  max-width: 1600px;
  margin: auto;
  border-top: 1px solid var(--border-color-subtle);
  color: var(--color-subtle);
  font-size: var(--font-size-small);
}
.spanish-footer p {
  margin: 0 0 8px;
}
.spanish-footer nav {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
}
@media (min-width: 800px) {
  .spanish-dashboard :deep(.dashboard-main) {
    grid-template-columns: minmax(0, 1fr) minmax(0, 34%);
  }
}
@media (max-width: 799px) {
  .spanish-footer {
    padding: 24px 16px;
  }
}
</style>
