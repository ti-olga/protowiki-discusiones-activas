export const WIKI_ORIGIN = 'https://es.wikipedia.org'
export const groups = [
  [
    'Páginas de la comunidad',
    [
      ['Ayuda del Café', 'Preguntas sobre cómo editar y usar Wikipedia.'],
      ['Café', 'Conversaciones sobre políticas, propuestas, cuestiones técnicas y otros asuntos.'],
      ['Encuestas y votaciones', 'Consultas abiertas a la participación de la comunidad.'],
    ],
  ],
  [
    'Páginas de discusión',
    [
      ['Usuarios', 'Conversaciones entre participantes de Wikipedia.'],
      ['Artículos', 'Conversaciones sobre cómo mejorar los artículos.'],
      ['Políticas y convenciones', 'Conversaciones sobre las normas de Wikipedia.'],
      ['Wikiproyectos', 'Coordinación de tareas sobre un tema concreto.'],
      ['Otras páginas', 'Conversaciones sobre plantillas, archivos, categorías, anexos y módulos.'],
    ],
  ],
  [
    'Tablones de anuncios',
    [
      ['Bibliotecarios', 'Solicitudes y asuntos del tablón de anuncios de los bibliotecarios.'],
      ['Fuentes fiables', 'Conversaciones sobre la fiabilidad de las fuentes y las referencias.'],
      ['Punto de vista neutral', 'Conversaciones sobre neutralidad, sesgos y equilibrio.'],
      ['Conflictos entre usuarios', 'Guerras de ediciones y problemas de etiqueta.'],
    ],
  ],
]
const cafe = 'Wikipedia:Café/Archivo/'
const tab = 'Wikipedia:Tablón de anuncios de los bibliotecarios/Portal/Archivo/'
export const venues = {
  'Ayuda del Café': [cafe + 'Ayuda/Actual'],
  Café: ['Políticas', 'Propuestas', 'Técnica', 'Miscelánea'].map(
    (section) => cafe + section + '/Actual',
  ),
  'Políticas y convenciones': [
    'Wikipedia discusión:Verificabilidad',
    'Wikipedia discusión:Punto de vista neutral',
    cafe + 'Políticas/Actual',
  ],
  Bibliotecarios: [
    tab + 'Miscelánea/Actual',
    tab + 'Protección de artículos/Actual',
    tab + 'Permisos/Actual',
  ],
  'Fuentes fiables': [
    'Wikipedia discusión:Fuentes fiables',
    cafe + 'Ayuda/Actual',
    cafe + 'Miscelánea/Actual',
    cafe + 'Políticas/Actual',
  ],
  'Punto de vista neutral': [
    'Wikipedia discusión:Punto de vista neutral',
    cafe + 'Ayuda/Actual',
    cafe + 'Miscelánea/Actual',
    cafe + 'Políticas/Actual',
  ],
  'Conflictos entre usuarios': [tab + '3RR/Actual', tab + 'Violaciones de etiqueta/Actual'],
}
export async function wikiAPI(params, signal) {
  const url = new URL('/w/api.php', WIKI_ORIGIN)
  url.search = new URLSearchParams({ format: 'json', formatversion: '2', origin: '*', ...params })
  let response
  for (let attempt = 0; attempt < 3; attempt++) {
    response = await fetch(url, { cache: 'no-store', signal: signal || AbortSignal.timeout(25000) })
    if (response.status !== 429 || attempt === 2) break
    const retry = Number(response.headers.get('Retry-After'))
    const delay = Number.isFinite(retry) && retry > 0 ? retry * 1000 : 1500 * (attempt + 1)
    if (delay > 15000) break
    await new Promise((resolve) => setTimeout(resolve, delay))
  }
  if (!response.ok) throw Error('Wikipedia ha devuelto el estado ' + response.status)
  const data = await response.json()
  if (data.error) throw Error(data.error.info)
  return data
}
export const wikiTextFromHTML = (html) =>
  new DOMParser()
    .parseFromString(html || '', 'text/html')
    .body.textContent.replace(/\s+/g, ' ')
    .trim()
export const isRecentDiscussion = (d) =>
  Number.isFinite(Number(d.latest)) &&
  d.latest > 0 &&
  Date.now() - d.latest >= 0 &&
  Date.now() - d.latest <= 30 * 86400000
export function discussionThreads(source, roots, type, interests = []) {
  const headings = []
  function find(items) {
    for (const item of items) {
      if (item.type === 'heading' && item.headingLevel === 2) headings.push(item)
      else if (item.type === 'heading') find(item.replies || [])
    }
  }
  find(roots)
  return headings
    .flatMap((thread) => {
      const comments = []
      function visit(item) {
        if (item.type === 'comment' && item.id && Number.isFinite(Date.parse(item.timestamp)))
          comments.push(item)
        for (const child of item.replies || []) visit(child)
      }
      visit(thread)
      if (!comments.length) return []
      comments.sort((a, b) => Date.parse(b.timestamp) - Date.parse(a.timestamp))
      const title = wikiTextFromHTML(thread.html)
      if (!title) return []
      const body = comments.map((comment) => wikiTextFromHTML(comment.html)).join('\n\n')
      const topics =
        type === 'Artículos'
          ? interests
          : interests.filter((interest) =>
              (title + ' ' + body)
                .toLocaleLowerCase('es')
                .includes(interest.toLocaleLowerCase('es')),
            )
      if (interests.length && !topics.length) return []
      const base = WIKI_ORIGIN + '/wiki/' + encodeURIComponent(source.replace(/ /g, '_'))
      return [
        {
          title,
          topicTitle: title,
          source,
          pageTitle: source,
          type,
          types: [type],
          topics,
          comments: Number.isInteger(thread.commentCount) ? thread.commentCount : comments.length,
          people: Number.isInteger(thread.authorCount)
            ? thread.authorCount
            : new Set(comments.map((c) => c.author).filter(Boolean)).size,
          latest: Date.parse(comments[0].timestamp),
          latestTimestamp: comments[0].timestamp,
          topicId: thread.id,
          topicName: thread.name,
          url: base + '#' + encodeURIComponent(title.replace(/ /g, '_')),
          body: body.slice(0, 2500),
          live: true,
          structured: true,
        },
      ]
    })
    .filter(isRecentDiscussion)
    .sort((a, b) => b.latest - a.latest)
}
const relative = new Intl.RelativeTimeFormat('es', { numeric: 'always', style: 'short' })
export function relativeWikiTime(timestamp) {
  const seconds = Math.max(0, Math.floor((Date.now() - timestamp) / 1000))
  return seconds < 60
    ? relative.format(-seconds, 'second')
    : seconds < 3600
      ? relative.format(-Math.floor(seconds / 60), 'minute')
      : seconds < 86400
        ? relative.format(-Math.floor(seconds / 3600), 'hour')
        : relative.format(-Math.floor(seconds / 86400), 'day')
}
const namespaces = {
  Usuarios: '3',
  Artículos: '1',
  Wikiproyectos: '103',
  'Otras páginas': '7|11|13|15|101|105|829',
}
export function createDiscussionLoader() {
  const cache = new Map(),
    queue = []
  let active = 0
  const drain = () => {
    while (active < 4 && queue.length) {
      const job = queue.shift()
      active++
      wikiAPI(job.params)
        .then(job.resolve, job.reject)
        .finally(() => {
          active--
          drain()
        })
    }
  }
  const api = (params) => {
    const key = JSON.stringify(params)
    if (!cache.has(key))
      cache.set(
        key,
        new Promise((resolve, reject) => {
          queue.push({ params, resolve, reject })
          drain()
        }),
      )
    return cache.get(key)
  }
  async function resolvePages(titles) {
    if (!titles.length) return []
    const data = await api({
      action: 'query',
      titles: titles.join('|'),
      redirects: 1,
      prop: 'info',
    })
    return (data.query?.pages || []).filter((p) => !p.missing).map((p) => p.title)
  }
  async function pagesForType(type, interests) {
    if (venues[type]) return resolvePages(venues[type])
    if (type === 'Artículos' && interests.length)
      return resolvePages(interests.map((title) => 'Discusión:' + title))
    if (type === 'Encuestas y votaciones') {
      const indexes = await Promise.all(
        ['Wikipedia:Encuestas', 'Wikipedia:Votaciones'].map(async (page) => {
          const sections = await api({ action: 'parse', page, prop: 'sections' })
          const section = sections.parse?.sections?.find((s) => /en curso/i.test(s.line))
          if (!section) return []
          const links = await api({ action: 'parse', page, section: section.index, prop: 'links' })
          return (links.parse?.links || [])
            .map((link) => link.title)
            .filter(
              (title) =>
                /^(Wikipedia(?: discusión)?:)(Encuestas|Votaciones)\//.test(title) &&
                !/(Archivo|cabecera|plantilla|Ayuda)/i.test(title),
            )
        }),
      )
      const category = await api({
        action: 'query',
        list: 'categorymembers',
        cmtitle: 'Categoría:Wikipedia:Votaciones en curso',
        cmnamespace: '4|5',
        cmlimit: '30',
      })
      const all = [
        ...indexes.flat(),
        ...(category.query?.categorymembers || [])
          .map((p) => p.title)
          .filter((t) => /^Wikipedia:Votaciones\//.test(t)),
      ]
      // The discussion subpages contain the actual conversation when voting pages only contain ballots.
      return resolvePages(
        [
          ...new Set([...all, ...all.map((t) => t.replace(/^Wikipedia:/, 'Wikipedia discusión:'))]),
        ].slice(0, 20),
      )
    }
    if (namespaces[type]) {
      const changes = await api({
        action: 'query',
        list: 'recentchanges',
        rcnamespace: namespaces[type],
        rctype: 'edit|new',
        rcshow: '!bot',
        rcprop: 'title|timestamp',
        rclimit: '50',
      })
      return [...new Set((changes.query?.recentchanges || []).map((p) => p.title))]
        .filter((title) => !/\/(Archivo|Archivos|archive)(\/|$)/i.test(title))
        .slice(0, type === 'Artículos' ? 10 : 6)
    }
    return []
  }
  async function pageThreads(page, type, interests) {
    const json = await api({ action: 'discussiontoolspageinfo', page, prop: 'threaditemshtml' })
    return discussionThreads(
      page,
      json.discussiontoolspageinfo?.threaditemshtml || [],
      type,
      interests,
    )
  }
  async function loadType(type, interests) {
    const pages = await pagesForType(type, interests)
    const results = await Promise.allSettled(
      pages.map((page) => pageThreads(page, type, interests)),
    )
    let rows = results.flatMap((r) => (r.status === 'fulfilled' ? r.value : []))
    if (type === 'Fuentes fiables')
      rows = rows.filter(
        (row) =>
          row.source.startsWith('Wikipedia discusión:Fuentes fiables') ||
          /fuentes?|referencias?|fiabilidad|verificabilidad/i.test(row.title + ' ' + row.body),
      )
    if (type === 'Punto de vista neutral')
      rows = rows.filter(
        (row) =>
          row.source.startsWith('Wikipedia discusión:Punto de vista neutral') ||
          /neutralidad|punto de vista|sesgo|imparcialidad/i.test(row.title + ' ' + row.body),
      )
    return { rows, failedPages: results.filter((r) => r.status === 'rejected').length, pages }
  }
  return { loadType, pageThreads, pagesForType }
}
export function mergeDiscussions(rows) {
  const merged = new Map()
  for (const row of rows) {
    const old = merged.get(row.url)
    merged.set(
      row.url,
      old
        ? {
            ...old,
            ...row,
            types: [...new Set([...old.types, ...row.types])],
            topics: [...new Set([...old.topics, ...row.topics])],
          }
        : row,
    )
  }
  return [...merged.values()]
}
