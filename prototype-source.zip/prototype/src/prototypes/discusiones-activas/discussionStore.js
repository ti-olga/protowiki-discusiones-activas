import { computed, reactive, ref, watch } from 'vue'
import {
  groups,
  WIKI_ORIGIN,
  isRecentDiscussion,
  createDiscussionLoader,
  mergeDiscussions,
} from './discussionData.js'
const KEY = 'protowiki-discusiones-es-pruebas-v1'
const safe = (d) =>
  d?.url?.startsWith(WIKI_ORIGIN + '/wiki/') && d.structured && isRecentDiscussion(d)
let saved = {}
try {
  saved = JSON.parse(localStorage.getItem(KEY) || '{}')
} catch {}
export const state = reactive({
  types: saved.types || [],
  interests: saved.interests || [],
  saved: { pins: [], subscriptions: [], view: 'all', ...saved.saved },
  records: (saved.records || []).filter(safe),
  liveUrls: saved.liveUrls || [],
  opened: saved.opened || {},
  preferences: saved.preferences || {},
  busy: false,
  error: '',
  limit: 3,
  expanded: false,
})
export const current = computed(() => state.saved)
export const clock = ref(Date.now())
const timer = setInterval(() => (clock.value = Date.now()), 15000)
if (import.meta.hot) import.meta.hot.dispose(() => clearInterval(timer))
const persisted = () => ({
  types: state.types,
  interests: state.interests,
  saved: state.saved,
  records: state.records,
  liveUrls: state.liveUrls,
  opened: state.opened,
  preferences: state.preferences,
})
watch(
  persisted,
  (value) => {
    try {
      localStorage.setItem(KEY, JSON.stringify(value))
    } catch {
      try {
        const ids = new Set([...state.saved.pins, ...state.saved.subscriptions])
        localStorage.setItem(
          KEY,
          JSON.stringify({ ...value, records: value.records.filter((d) => ids.has(d.url)) }),
        )
      } catch {
        state.error = 'No se han podido guardar las preferencias en este navegador.'
      }
    }
  },
  { deep: true },
)
export const pendingRemoval = reactive({ pins: [], subscriptions: [] })
const recent = computed(() => state.records.filter(safe))
export const pinned = computed(() =>
  recent.value
    .filter((d) => current.value.pins.includes(d.url))
    .sort((a, b) => b.latest - a.latest),
)
export const subscribed = computed(() =>
  recent.value
    .filter((d) => current.value.subscriptions.includes(d.url))
    .sort((a, b) => b.latest - a.latest),
)
export const ordered = computed(() => {
  if (current.value.view === 'pinned') return recent.value.filter(d => current.value.pins.includes(d.url) || pendingRemoval.pins.includes(d.url)).sort((a,b) => b.latest-a.latest)
  if (current.value.view === 'subscribed') return recent.value.filter(d => current.value.subscriptions.includes(d.url) || pendingRemoval.subscriptions.includes(d.url)).sort((a,b) => b.latest-a.latest)
  const matching = recent.value.filter(
    (d) =>
      state.liveUrls.includes(d.url) &&
      (!state.types.length || d.types.some((type) => state.types.includes(type))) &&
      (!state.interests.length || d.topics.some((t) => state.interests.includes(t))),
  )
  matching.sort(
    (a, b) =>
      (state.preferences[b.url] || 0) - (state.preferences[a.url] || 0) || b.latest - a.latest,
  )
  const featured = matching
    .filter((d) => d.types.includes('Encuestas y votaciones'))
    .sort((a, b) => b.comments - a.comments || b.latest - a.latest)[0]
  return featured ? [featured, ...matching.filter((d) => d.url !== featured.url)] : matching
})
export const readKey = (d) => d.source + '|' + (d.topicName || d.topicId || d.title)
export const isOpened = (d) => !!state.opened[readKey(d)]
export const hasNew = (d) => {
  const read = state.opened[readKey(d)]
  return !!read && d.latest > Math.max(read.openedAt || 0, read.latest || 0)
}
export function markOpened(d) {
  state.opened[readKey(d)] = { openedAt: Date.now(), latest: d.latest }
}
export function resetLimit() {
  state.limit = 3
  state.expanded = false
}
const quickRemovalTimers = new Map()
if (import.meta.hot) import.meta.hot.dispose(() => {
  for (const timer of quickRemovalTimers.values()) clearTimeout(timer)
})
export function toggleSaved(kind, d, deferRemoval = false) {
  const ids = current.value[kind]
  const index = ids.indexOf(d.url)
  {
    const timerKey = kind + ':' + d.url
    clearTimeout(quickRemovalTimers.get(timerKey))
    quickRemovalTimers.delete(timerKey)
    const retained = pendingRemoval[kind]
    const previous = retained.indexOf(d.url)
    if (previous >= 0) retained.splice(previous, 1)
    if (index >= 0 && deferRemoval) {
      retained.push(d.url)
      const timer = setTimeout(() => {
        const position = pendingRemoval[kind].indexOf(d.url)
        if (position >= 0) pendingRemoval[kind].splice(position, 1)
        quickRemovalTimers.delete(timerKey)
      }, 3000)
      timer.unref?.()
      quickRemovalTimers.set(timerKey, timer)
    }
  }
  if (index < 0) ids.push(d.url)
  else ids.splice(index, 1)
  return index < 0
}
let started = false,
  generation = 0
export async function loadDiscussions() {
  started = true
  const request = ++generation
  state.busy = true
  state.error = ''
  resetLimit()
  const loader = createDiscussionLoader(),
    types = state.types.length
      ? [...state.types]
      : groups.flatMap(([, items]) => items.map(([type]) => type)),
    interests = [...state.interests]
  const results = await Promise.allSettled(types.map((type) => loader.loadType(type, interests)))
  if (request !== generation) return
  const found = mergeDiscussions(
    results.flatMap((r) => (r.status === 'fulfilled' ? r.value.rows : [])),
  )
  const savedIds = new Set([...current.value.pins, ...current.value.subscriptions])
  const cached = state.records.filter((d) => savedIds.has(d.url))
  const updates = await Promise.allSettled(
    [...new Set(cached.map((d) => d.source))].map(async (source) =>
      loader.pageThreads(source, cached.find((d) => d.source === source).type, []),
    ),
  )
  if (request !== generation) return
  const records = new Map(state.records.map((d) => [d.url, d]))
  for (const update of updates)
    if (update.status === 'fulfilled')
      for (const row of update.value) {
        const old = records.get(row.url)
        if (savedIds.has(row.url) && old)
          records.set(row.url, { ...row, types: old.types, topics: old.topics })
      }
  for (const row of found) records.set(row.url, row)
  state.records = [...records.values()].filter(safe)
  state.liveUrls = found.map((d) => d.url)
  state.busy = false
  const failed =
    results.filter((r) => r.status === 'rejected').length +
    results.reduce((n, r) => n + (r.status === 'fulfilled' ? r.value.failedPages : 0), 0)
  if (failed) state.error = 'No se han podido cargar algunas discusiones. Vuelve a intentarlo.'
}
export function ensureLoaded() {
  if (!started) loadDiscussions()
}
