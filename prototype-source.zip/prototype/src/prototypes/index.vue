<script setup>
import DashboardPage from './discusiones-activas/DashboardPage.vue'
definePage({meta:{platform:'web',hidden:true}})
</script>
<template><DashboardPage/></template>
