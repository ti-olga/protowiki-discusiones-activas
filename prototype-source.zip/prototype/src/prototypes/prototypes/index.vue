<script setup>
import { onUnmounted } from 'vue'
import { CdxButton, CdxCard } from '@wikimedia/codex'
import ChromeWrapper from '@/components/chrome/ChromeWrapper.vue'
import SpecialPageWrapper from '@/components/SpecialPageWrapper.vue'
definePage({meta:{platform:'web',hidden:true}})
const base=import.meta.env.BASE_URL
const oldTitle=document.title, oldLang=document.documentElement.lang, oldDir=document.documentElement.dir
document.documentElement.lang='en'; document.documentElement.dir='ltr'; document.title='Active discussions prototypes'
onUnmounted(()=>{document.documentElement.lang=oldLang;document.documentElement.dir=oldDir;document.title=oldTitle})
</script>
<template>
<ChromeWrapper lang="en" dir="ltr" :prototyping-settings="false" :last-edited-notice="false" :show-footer="false">
<SpecialPageWrapper title="Active discussions prototypes">
<p>Choose a language or an English design version.</p>
<div class="prototype-groups">
<CdxCard><template #title>English</template><template #description>Versions A–D</template><template #supporting-text><div class="prototype-links"><a class="cdx-button cdx-button--fake-button cdx-button--fake-button--enabled" v-for="version in ['A','B','C','D']" :key="version" :href="`${base}active-discussions?version=${version}`">Version {{ version }}</a></div></template></CdxCard>
<CdxCard><template #title>Español</template><template #description>Versión B · Spanish Wikipedia</template><template #supporting-text><a class="cdx-button cdx-button--fake-button cdx-button--fake-button--enabled" :href="base">Abrir prototipo</a></template></CdxCard>
<CdxCard><template #title><span lang="ar" dir="rtl">العربية</span></template><template #description>Version B · Arabic Wikipedia · Right to left</template><template #supporting-text><a class="cdx-button cdx-button--fake-button cdx-button--fake-button--enabled" href="https://protowiki-active-discussions-ar-olga.noisy-myna-4394.chatgpt.site/" lang="ar" dir="rtl">فتح النموذج</a></template></CdxCard>
<CdxCard><template #title><span lang="hi">हिन्दी</span></template><template #description>Version B · Hindi Wikipedia</template><template #supporting-text><a class="cdx-button cdx-button--fake-button cdx-button--fake-button--enabled" href="https://protowiki-active-discussions-hi-olga.noisy-myna-4394.chatgpt.site/" lang="hi">प्रोटोटाइप खोलें</a></template></CdxCard>
</div></SpecialPageWrapper></ChromeWrapper>
</template>
<style scoped>.prototype-groups{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,300px),1fr));gap:16px;max-width:1000px;margin:24px 0}.prototype-links{display:flex;gap:8px;flex-wrap:wrap}.prototype-groups :deep(.cdx-card){padding:16px}</style>
